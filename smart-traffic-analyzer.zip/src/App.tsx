import { useCallback, useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import HomeDashboard, { type NavTab } from './components/HomeDashboard';
import LiveTrafficMap from './components/LiveTrafficMap';
import VehicleDetectionView from './components/VehicleDetectionView';
import TrafficAnalyticsView from './components/TrafficAnalyticsView';
import PredictionView from './components/PredictionView';
import SignalManagementView from './components/SignalManagementView';
import ReportsView from './components/ReportsView';
import type { TrafficSnapshot } from './types/traffic';

const NAV_ITEMS: { id: NavTab; label: string }[] = [
  { id: 'home', label: 'Home' },
  { id: 'live-traffic', label: 'Live Traffic' },
  { id: 'vehicle-detection', label: 'Vehicle Detection' },
  { id: 'analytics', label: 'Analytics' },
  { id: 'prediction', label: 'Prediction' },
  { id: 'signals', label: 'Signals' },
  { id: 'reports', label: 'Reports' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [snapshot, setSnapshot] = useState<TrafficSnapshot | null>(null);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const [routeOriginId, setRouteOriginId] = useState<string | null>(null);
  const [routeDestId, setRouteDestId] = useState<string | null>(null);
  const [sampleFeedSelection, setSampleFeedSelection] = useState<{
    url: string;
    label: string;
  } | null>(null);

  const loadSnapshot = useCallback(async () => {
    try {
      const res = await fetch('/api/traffic/snapshot');
      if (!res.ok) {
        throw new Error('Failed to load traffic network snapshot.');
      }
      const data = (await res.json()) as TrafficSnapshot;
      setSnapshot(data);
      setFetchError(null);
    } catch (err) {
      setFetchError(err instanceof Error ? err.message : 'Unable to reach traffic server.');
    }
  }, []);

  useEffect(() => {
    void loadSnapshot();
    const poll = setInterval(() => {
      void loadSnapshot();
    }, 5000);
    return () => clearInterval(poll);
  }, [loadSnapshot]);

  // Smooth 1-second local countdown tick for traffic signals
  useEffect(() => {
    const timer = setInterval(() => {
      setSnapshot((prev) => {
        if (!prev) return prev;
        return {
          ...prev,
          signals: prev.signals.map((sig) => {
            if (sig.remainingSec > 1) {
              return { ...sig, remainingSec: sig.remainingSec - 1 };
            }
            if (sig.currentPhase === 'green') {
              return {
                ...sig,
                currentPhase: 'yellow',
                remainingSec: sig.timings.yellowSec,
              };
            }
            if (sig.currentPhase === 'yellow') {
              return {
                ...sig,
                currentPhase: 'red',
                remainingSec: sig.timings.redSec,
              };
            }
            return {
              ...sig,
              currentPhase: 'green',
              remainingSec: sig.timings.greenSec,
            };
          }),
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleNavigate = (tab: NavTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleQuickRoutePredict = (originId: string, destinationId: string) => {
    setRouteOriginId(originId);
    setRouteDestId(destinationId);
    handleNavigate('prediction');
  };

  const handleInspectCameraSample = (url: string, label: string) => {
    setSampleFeedSelection({ url, label });
    handleNavigate('vehicle-detection');
  };

  return (
    <div className="min-h-screen bg-[#050810] text-slate-100 flex flex-col">
      {/* Top Navigation Bar */}
      <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#050810]/95 backdrop-blur-md">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-6 px-4 py-3.5 sm:px-6 lg:px-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => handleNavigate('home')}
            className="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#00E676]"
          >
            Smart Traffic <span className="text-[#00E676]">Analyzer</span>
          </button>

          {/* Zone 2: Clean Single-Line Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden lg:flex items-center gap-6 text-sm font-medium"
          >
            {NAV_ITEMS.map((item) => {
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`relative py-1 transition-colors whitespace-nowrap shrink-0 ${
                    active ? 'text-[#00E676]' : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {item.label}
                  {active && (
                    <span className="absolute inset-x-0 -bottom-[15px] h-0.5 bg-[#00E676]" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary Action + Mobile Menu Trigger */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => handleNavigate('vehicle-detection')}
              className="hidden sm:inline-flex items-center rounded-lg bg-[#00E676] px-4 py-2 text-xs font-semibold text-[#04120B] transition-colors hover:bg-[#1FF58A] whitespace-nowrap shrink-0"
            >
              Analyze Feed
            </button>
            <button
              type="button"
              aria-label="Toggle navigation menu"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-800 bg-[#0A1324] text-slate-200 lg:hidden"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Responsive Mobile Drawer */}
        {mobileMenuOpen && (
          <nav
            aria-label="Mobile Navigation"
            className="border-t border-slate-800 bg-[#080F1E] px-4 py-3 lg:hidden"
          >
            <div className="grid grid-cols-2 gap-2">
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleNavigate(item.id)}
                  className={`rounded-lg px-3 py-2.5 text-left text-sm font-medium transition-colors ${
                    activeTab === item.id
                      ? 'bg-[#00E676]/15 text-[#00E676]'
                      : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </nav>
        )}
      </header>

      {/* Main Content Container */}
      <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        {fetchError && !snapshot ? (
          <div className="rounded-xl border border-[#EF4444]/40 bg-[#EF4444]/10 p-6 text-sm text-red-200">
            {fetchError}
          </div>
        ) : !snapshot ? (
          <div className="space-y-6">
            <div className="h-44 animate-pulse rounded-xl border border-slate-800 bg-[#0A1324]" />
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className="h-28 animate-pulse rounded-xl border border-slate-800 bg-[#0A1324]"
                />
              ))}
            </div>
          </div>
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeDashboard
                snapshot={snapshot}
                onNavigate={handleNavigate}
                onQuickRoutePredict={handleQuickRoutePredict}
                onInspectCameraSample={handleInspectCameraSample}
              />
            )}
            {activeTab === 'live-traffic' && <LiveTrafficMap snapshot={snapshot} />}
            {activeTab === 'vehicle-detection' && (
              <VehicleDetectionView
                snapshot={snapshot}
                initialSample={sampleFeedSelection}
                onAnalysisRecorded={() => void loadSnapshot()}
              />
            )}
            {activeTab === 'analytics' && <TrafficAnalyticsView snapshot={snapshot} />}
            {activeTab === 'prediction' && (
              <PredictionView
                snapshot={snapshot}
                initialOriginId={routeOriginId}
                initialDestinationId={routeDestId}
              />
            )}
            {activeTab === 'signals' && (
              <SignalManagementView
                snapshot={snapshot}
                onSignalUpdated={(updated) => setSnapshot(updated)}
              />
            )}
            {activeTab === 'reports' && <ReportsView snapshot={snapshot} />}
          </>
        )}
      </main>

      {/* Clean Minimal Footer */}
      <footer className="border-t border-slate-800/80 bg-[#050810] px-4 py-5 sm:px-6 lg:px-8">
        <div className="mx-auto flex max-w-[1440px] flex-col items-start justify-between gap-2 text-xs text-slate-400 sm:flex-row sm:items-center">
          <p>
            Smart Traffic Analyzer · Corridor telemetry uses simulated sensor data; camera uploads
            and forecasts run live AI analysis.
          </p>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => handleNavigate('live-traffic')}
              className="hover:text-white"
            >
              Live Map
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('signals')}
              className="hover:text-white"
            >
              Signal Control
            </button>
            <button
              type="button"
              onClick={() => handleNavigate('reports')}
              className="hover:text-white"
            >
              Export Reports
            </button>
            <a
              href="/api/project/download-zip"
              download="smart-traffic-analyzer.zip"
              className="text-[#00E676] hover:underline"
            >
              Download Source ZIP
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
