import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Title,
  Tooltip,
} from 'chart.js';
import type { DensityLevel, VehicleBreakdown } from '../types/traffic';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  PointElement,
  LineElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export const DENSITY_META: Record<
  DensityLevel,
  {
    label: string;
    shortLabel: string;
    hex: string;
    textClass: string;
    bgTintClass: string;
    borderClass: string;
  }
> = {
  low: {
    label: 'Low Traffic',
    shortLabel: 'Low',
    hex: '#22C55E',
    textClass: 'text-[#22C55E]',
    bgTintClass: 'bg-[#22C55E]/12',
    borderClass: 'border-[#22C55E]/30',
  },
  moderate: {
    label: 'Moderate Traffic',
    shortLabel: 'Moderate',
    hex: '#EAB308',
    textClass: 'text-[#EAB308]',
    bgTintClass: 'bg-[#EAB308]/12',
    borderClass: 'border-[#EAB308]/30',
  },
  heavy: {
    label: 'Heavy Traffic',
    shortLabel: 'Heavy',
    hex: '#F97316',
    textClass: 'text-[#F97316]',
    bgTintClass: 'bg-[#F97316]/12',
    borderClass: 'border-[#F97316]/30',
  },
  severe: {
    label: 'Severe Congestion',
    shortLabel: 'Severe',
    hex: '#EF4444',
    textClass: 'text-[#EF4444]',
    bgTintClass: 'bg-[#EF4444]/12',
    borderClass: 'border-[#EF4444]/30',
  },
};

export const VEHICLE_LABELS: {
  key: keyof VehicleBreakdown;
  label: string;
  color: string;
}[] = [
  { key: 'cars', label: 'Cars', color: '#38BDF8' },
  { key: 'bikes', label: 'Bikes', color: '#00E676' },
  { key: 'buses', label: 'Buses', color: '#FACC15' },
  { key: 'trucks', label: 'Trucks', color: '#FB923C' },
  { key: 'autoRickshaws', label: 'Auto-rickshaws', color: '#A78BFA' },
];

export function formatNumber(n: number): string {
  return new Intl.NumberFormat('en-US').format(Math.round(n));
}

export function formatTimeShort(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return iso;
  }
}

export const DARK_CHART_OPTIONS_BASE = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      labels: {
        color: '#CBD5E1',
        font: {
          family: '"Plus Jakarta Sans", sans-serif',
          size: 12,
        },
        boxWidth: 12,
        usePointStyle: true,
      },
    },
    tooltip: {
      backgroundColor: '#0A1324',
      titleColor: '#F8FAFC',
      bodyColor: '#CBD5E1',
      borderColor: 'rgba(148, 163, 184, 0.25)',
      borderWidth: 1,
      padding: 10,
    },
  },
  scales: {
    x: {
      grid: {
        color: 'rgba(148, 163, 184, 0.08)',
      },
      ticks: {
        color: '#94A3B8',
        font: {
          family: '"JetBrains Mono", monospace',
          size: 11,
        },
      },
    },
    y: {
      grid: {
        color: 'rgba(148, 163, 184, 0.08)',
      },
      ticks: {
        color: '#94A3B8',
        font: {
          family: '"JetBrains Mono", monospace',
          size: 11,
        },
      },
    },
  },
};
