import { useState } from 'react';
import { Bar } from 'react-chartjs-2';
import { Download, FileSpreadsheet, FileText, Printer } from 'lucide-react';
import type { ReportTimeframe, TrafficSnapshot } from '../types/traffic';
import {
  DARK_CHART_OPTIONS_BASE,
  DENSITY_META,
  VEHICLE_LABELS,
  formatNumber,
} from '../utils/trafficFormat';

interface ReportsViewProps {
  snapshot: TrafficSnapshot;
}

export default function ReportsView({ snapshot }: ReportsViewProps) {
  const [timeframe, setTimeframe] = useState<ReportTimeframe>('daily');
  const activeReport = snapshot.reports[timeframe];

  const comparisonChartData = {
    labels: activeReport.dayComparison.map((d) => d.label),
    datasets: [
      {
        label: 'Current Period Vehicles',
        data: activeReport.dayComparison.map((d) => d.todayVehicles),
        backgroundColor: '#00E676',
        borderRadius: 6,
      },
      {
        label: 'Previous Period Vehicles',
        data: activeReport.dayComparison.map((d) => d.previousPeriodVehicles),
        backgroundColor: '#334155',
        borderRadius: 6,
      },
    ],
  };

  const triggerDownload = (format: 'csv' | 'json') => {
    window.location.href = `/api/reports/download?timeframe=${timeframe}&format=${format}`;
  };

  const avgCongestionPct = Math.round(
    activeReport.congestionPct.reduce((a, b) => a + b, 0) /
      Math.max(1, activeReport.congestionPct.length)
  );

  return (
    <div className="space-y-6">
      {/* Header & Export Actions */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">Reports & Analytics</span>
            <span aria-hidden="true">·</span>
            <span>Simulated Comparative Dataset</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            Traffic Reports & Day-Over-Day Comparison
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0A1324] p-1">
            {(['daily', 'weekly', 'monthly'] as ReportTimeframe[]).map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => setTimeframe(tf)}
                className={`rounded-md px-3 py-1.5 text-xs font-semibold capitalize transition-colors whitespace-nowrap ${
                  timeframe === tf
                    ? 'bg-[#00E676] text-[#04120B]'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => triggerDownload('csv')}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E676] px-3.5 py-2 text-xs font-semibold text-[#04120B] hover:bg-[#1FF58A] whitespace-nowrap"
          >
            <FileSpreadsheet className="h-3.5 w-3.5" />
            Download CSV
          </button>

          <button
            type="button"
            onClick={() => triggerDownload('json')}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0A1324] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-slate-500 whitespace-nowrap"
          >
            <Download className="h-3.5 w-3.5 text-[#00E676]" />
            Download JSON
          </button>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#0A1324] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-slate-500 whitespace-nowrap"
          >
            <Printer className="h-3.5 w-3.5" />
            Print Report
          </button>
        </div>
      </div>

      {/* Vehicle Count Statistics + Congestion % */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {VEHICLE_LABELS.map((item) => (
          <div
            key={item.key}
            className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-4"
          >
            <p className="text-xs text-slate-400">{item.label}</p>
            <p className="mt-1.5 font-mono text-xl font-bold text-white tabular-nums">
              {formatNumber(activeReport.vehicleDistribution[item.key])}
            </p>
          </div>
        ))}
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-4">
          <p className="text-xs text-slate-400">Avg Congestion</p>
          <p className="mt-1.5 font-mono text-xl font-bold text-[#FACC15] tabular-nums">
            {avgCongestionPct}%
          </p>
        </div>
      </div>

      {/* Comparison Chart + Delta Table */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-6">
          <h2 className="font-display text-lg font-semibold text-white">
            Period-over-Period Volume Comparison
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Current vs prior baseline across key time windows
          </p>
          <div className="mt-4 h-72">
            <Bar data={comparisonChartData} options={DARK_CHART_OPTIONS_BASE} />
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-6">
          <div className="mb-3 flex items-center gap-2">
            <FileText className="h-4 w-4 text-[#00E676]" />
            <h2 className="font-display text-lg font-semibold text-white">
              Day & Period Comparison Matrix
            </h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2.5 pr-3 font-medium">Window</th>
                  <th className="px-3 py-2.5 text-right font-medium">Current</th>
                  <th className="px-3 py-2.5 text-right font-medium">Prior</th>
                  <th className="px-3 py-2.5 text-right font-medium">Congestion Δ</th>
                  <th className="pl-3 py-2.5 text-right font-medium">Speed Δ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {activeReport.dayComparison.map((row, i) => (
                  <tr key={i} className="hover:bg-slate-800/30">
                    <td className="py-3 pr-3 font-medium text-white">{row.label}</td>
                    <td className="px-3 py-3 text-right font-mono tabular-nums text-white">
                      {formatNumber(row.todayVehicles)}
                    </td>
                    <td className="px-3 py-3 text-right font-mono tabular-nums text-slate-400">
                      {formatNumber(row.previousPeriodVehicles)}
                    </td>
                    <td
                      className={`px-3 py-3 text-right font-mono font-semibold tabular-nums ${
                        row.congestionDeltaPct > 0 ? 'text-[#EF4444]' : 'text-[#22C55E]'
                      }`}
                    >
                      {row.congestionDeltaPct > 0 ? '+' : ''}
                      {row.congestionDeltaPct}%
                    </td>
                    <td
                      className={`pl-3 py-3 text-right font-mono font-semibold tabular-nums ${
                        row.avgSpeedDeltaKmh < 0 ? 'text-[#F97316]' : 'text-[#22C55E]'
                      }`}
                    >
                      {row.avgSpeedDeltaKmh > 0 ? '+' : ''}
                      {row.avgSpeedDeltaKmh} km/h
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Full Corridor Audit Table */}
      <section className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
        <h2 className="font-display text-lg font-semibold text-white">
          Corridor Congestion & Speed Audit
        </h2>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="py-2 pr-4 font-medium">Corridor</th>
                <th className="px-3 py-2 font-medium">Zone</th>
                <th className="px-3 py-2 font-medium">Severity</th>
                <th className="px-3 py-2 text-right font-medium">Congestion %</th>
                <th className="px-3 py-2 text-right font-medium">Avg Speed</th>
                <th className="pl-3 py-2 text-right font-medium">Total Vehicles</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {snapshot.corridors.map((c) => {
                const meta = DENSITY_META[c.densityLevel];
                return (
                  <tr key={c.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 pr-4 font-medium text-white">{c.name}</td>
                    <td className="px-3 py-2.5 text-slate-400">{c.zone}</td>
                    <td className={`px-3 py-2.5 font-medium ${meta.textClass}`}>
                      {meta.label}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {c.densityScore}%
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                      {c.avgSpeedKmh} km/h
                    </td>
                    <td className="pl-3 py-2.5 text-right font-mono font-semibold tabular-nums text-white">
                      {formatNumber(c.totalVehicles)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
