import { useCallback, useEffect, useRef, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Camera,
  Eye,
  EyeOff,
  Film,
  Loader2,
  Sparkles,
  Upload,
} from 'lucide-react';
import type { TrafficSnapshot, VisionAnalysisRecord } from '../types/traffic';
import {
  DARK_CHART_OPTIONS_BASE,
  DENSITY_META,
  VEHICLE_LABELS,
  formatNumber,
  formatTimeShort,
} from '../utils/trafficFormat';

interface VehicleDetectionViewProps {
  snapshot: TrafficSnapshot;
  initialSample: { url: string; label: string } | null;
  onAnalysisRecorded: () => void;
}

const SAMPLE_SCENES = [
  {
    id: 'highway',
    label: 'Outer Ring Express Cam 04',
    url: '/src/assets/images/traffic_cam_highway_1795507185041.jpg',
  },
  {
    id: 'junction',
    label: 'Trinity Circle Junction Cam 01',
    url: '/src/assets/images/traffic_cam_junction_1795507185390.jpg',
  },
  {
    id: 'congestion',
    label: 'Silk Board Overpass Cam 09',
    url: '/src/assets/images/traffic_cam_congestion_1795507185977.jpg',
  },
];

const CATEGORY_COLORS: Record<string, string> = {
  car: '#38BDF8',
  bike: '#00E676',
  bus: '#FACC15',
  truck: '#FB923C',
  auto_rickshaw: '#A78BFA',
};

export default function VehicleDetectionView({
  snapshot,
  initialSample,
  onAnalysisRecorded,
}: VehicleDetectionViewProps) {
  const [previewUrl, setPreviewUrl] = useState<string>(
    initialSample?.url ?? SAMPLE_SCENES[1].url
  );
  const [cameraLabel, setCameraLabel] = useState<string>(
    initialSample?.label ?? SAMPLE_SCENES[1].label
  );
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [showBoxes, setShowBoxes] = useState<boolean>(true);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<VisionAnalysisRecord | null>(
    snapshot.recentVisionAnalyses[0] ?? null
  );

  const imgRef = useRef<HTMLImageElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const drawBoundingBoxes = useCallback(() => {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;

    const width = img.clientWidth;
    const height = img.clientHeight;
    if (width === 0 || height === 0) return;

    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, width, height);
    if (!showBoxes || !analysis || analysis.detections.length === 0) return;

    analysis.detections.forEach((det) => {
      const [ymin, xmin, ymax, xmax] = det.box_2d;
      const x = (xmin / 1000) * width;
      const y = (ymin / 1000) * height;
      const w = ((xmax - xmin) / 1000) * width;
      const h = ((ymax - ymin) / 1000) * height;

      if (w <= 4 || h <= 4) return;
      const color = CATEGORY_COLORS[det.category] ?? '#00E676';

      ctx.strokeStyle = color;
      ctx.lineWidth = 2;
      ctx.strokeRect(x, y, w, h);

      const tag = `${det.label} ${Math.round(det.confidence * 100)}%`;
      ctx.font = '600 11px "JetBrains Mono", monospace';
      const textWidth = ctx.measureText(tag).width;
      const labelY = y > 18 ? y - 18 : y;

      ctx.fillStyle = 'rgba(5, 8, 16, 0.85)';
      ctx.fillRect(x, labelY, textWidth + 8, 17);
      ctx.fillStyle = color;
      ctx.fillText(tag, x + 4, labelY + 12);
    });
  }, [analysis, showBoxes]);

  useEffect(() => {
    drawBoundingBoxes();
    window.addEventListener('resize', drawBoundingBoxes);
    return () => window.removeEventListener('resize', drawBoundingBoxes);
  }, [drawBoundingBoxes, previewUrl]);

  const runDetectionOnBase64 = useCallback(
    async (
      base64Data: string,
      mimeType: string,
      label: string,
      mediaType: 'image' | 'video_frame'
    ) => {
      setIsAnalyzing(true);
      setErrorMsg(null);
      try {
        const res = await fetch('/api/analyze-media', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Data,
            mimeType,
            cameraLabel: label,
            mediaType,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Vehicle detection request failed.');
        }
        setAnalysis(data as VisionAnalysisRecord);
        onAnalysisRecorded();
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Unable to analyze media.');
      } finally {
        setIsAnalyzing(false);
      }
    },
    [onAnalysisRecorded]
  );

  const analyzeImageUrl = useCallback(
    async (url: string, label: string) => {
      setVideoSrc(null);
      setPreviewUrl(url);
      setCameraLabel(label);
      setErrorMsg(null);

      try {
        const imgResp = await fetch(url);
        const blob = await imgResp.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = String(reader.result ?? '');
          void runDetectionOnBase64(result, blob.type || 'image/jpeg', label, 'image');
        };
        reader.readAsDataURL(blob);
      } catch {
        setErrorMsg('Failed to load sample traffic frame.');
      }
    },
    [runDetectionOnBase64]
  );

  useEffect(() => {
    if (initialSample) {
      void analyzeImageUrl(initialSample.url, initialSample.label);
    }
  }, [initialSample, analyzeImageUrl]);

  const handleFileUpload = (file: File) => {
    setErrorMsg(null);
    if (file.type.startsWith('video/')) {
      const objUrl = URL.createObjectURL(file);
      setVideoSrc(objUrl);
      setCameraLabel(file.name);
      return;
    }

    if (file.type.startsWith('image/')) {
      setVideoSrc(null);
      const reader = new FileReader();
      reader.onloadend = () => {
        const dataUrl = String(reader.result ?? '');
        setPreviewUrl(dataUrl);
        setCameraLabel(file.name);
        void runDetectionOnBase64(dataUrl, file.type, file.name, 'image');
      };
      reader.readAsDataURL(file);
      return;
    }

    setErrorMsg('Please upload a valid image (JPG, PNG, WebP) or video (MP4, WebM).');
  };

  const captureVideoFrameAndAnalyze = () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) {
      setErrorMsg('Video frame is not ready yet. Play or seek the video first.');
      return;
    }
    const offscreen = document.createElement('canvas');
    const maxW = 1280;
    const scale = Math.min(1, maxW / video.videoWidth);
    offscreen.width = Math.round(video.videoWidth * scale);
    offscreen.height = Math.round(video.videoHeight * scale);
    const ctx = offscreen.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, offscreen.width, offscreen.height);
    const dataUrl = offscreen.toDataURL('image/jpeg', 0.9);
    setPreviewUrl(dataUrl);
    void runDetectionOnBase64(dataUrl, 'image/jpeg', `${cameraLabel} (Frame)`, 'video_frame');
  };

  const activeCounts = analysis ? analysis.vehicles : snapshot.summary.vehicleTotals;
  const activeTotal = analysis
    ? analysis.totalVehicles
    : snapshot.summary.totalVehiclesDetected;

  const barChartData = {
    labels: VEHICLE_LABELS.map((v) => v.label),
    datasets: [
      {
        label: analysis ? 'Detected in Current Feed' : 'Simulated Grid Totals',
        data: VEHICLE_LABELS.map((v) => activeCounts[v.key]),
        backgroundColor: VEHICLE_LABELS.map((v) => v.color),
        borderRadius: 6,
      },
    ],
  };

  const doughnutData = {
    labels: VEHICLE_LABELS.map((v) => v.label),
    datasets: [
      {
        data: VEHICLE_LABELS.map((v) => activeCounts[v.key]),
        backgroundColor: VEHICLE_LABELS.map((v) => v.color),
        borderColor: '#0A1324',
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">
              {analysis ? 'Live AI Vision · Gemini Multimodal' : 'Simulated Sensor Baseline'}
            </span>
            <span aria-hidden="true">·</span>
            <span>5-Class Vehicle Detection</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            Vehicle Detection and Counting
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) handleFileUpload(file);
            }}
          />
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-4 py-2 text-sm font-semibold text-[#04120B] transition-colors hover:bg-[#1FF58A] whitespace-nowrap shrink-0"
          >
            <Upload className="h-4 w-4" />
            Upload Image or Video
          </button>
          <button
            type="button"
            onClick={() => setShowBoxes((prev) => !prev)}
            className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0A1324] px-3.5 py-2 text-xs font-medium text-slate-200 hover:border-slate-500 whitespace-nowrap shrink-0"
          >
            {showBoxes ? <Eye className="h-4 w-4 text-[#00E676]" /> : <EyeOff className="h-4 w-4" />}
            {showBoxes ? 'Boxes Visible' : 'Boxes Hidden'}
          </button>
        </div>
      </div>

      {/* 6 Vehicle Count Cards */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {VEHICLE_LABELS.map((item) => (
          <div
            key={item.key}
            className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-4"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400">{item.label}</span>
              <span
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: item.color }}
              />
            </div>
            <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
              {formatNumber(activeCounts[item.key])}
            </p>
          </div>
        ))}
        <div className="rounded-xl border border-[#00E676]/40 bg-[#081918] p-4">
          <span className="text-xs font-medium text-[#00E676]">Total Vehicles</span>
          <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
            {formatNumber(activeTotal)}
          </p>
        </div>
      </div>

      {/* Detection Canvas + Video/Sample Controls */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="space-y-4 rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Camera className="h-4 w-4 text-[#00E676]" />
              <span className="text-sm font-semibold text-white">{cameraLabel}</span>
            </div>
            {!videoSrc && (
              <button
                type="button"
                disabled={isAnalyzing}
                onClick={() => void analyzeImageUrl(previewUrl, cameraLabel)}
                className="inline-flex items-center gap-1.5 rounded-lg border border-[#00E676]/40 bg-[#00E676]/12 px-3 py-1.5 text-xs font-semibold text-[#00E676] hover:bg-[#00E676]/20 disabled:opacity-50 whitespace-nowrap"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Detecting Vehicles...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5" />
                    Analyze Current Feed
                  </>
                )}
              </button>
            )}
          </div>

          {errorMsg && (
            <div className="rounded-lg border border-[#EF4444]/40 bg-[#EF4444]/10 p-3 text-xs text-red-200">
              {errorMsg}
            </div>
          )}

          {videoSrc ? (
            <div className="space-y-3">
              <div className="overflow-hidden rounded-lg border border-slate-800 bg-black">
                <video
                  ref={videoRef}
                  src={videoSrc}
                  controls
                  className="max-h-[380px] w-full object-contain"
                />
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <span className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Film className="h-3.5 w-3.5" />
                  Pause or scrub to any frame, then run AI vehicle detection
                </span>
                <button
                  type="button"
                  disabled={isAnalyzing}
                  onClick={captureVideoFrameAndAnalyze}
                  className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-4 py-2 text-xs font-semibold text-[#04120B] hover:bg-[#1FF58A] disabled:opacity-50"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      Analyzing Frame...
                    </>
                  ) : (
                    'Capture & Analyze Video Frame'
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="relative overflow-hidden rounded-lg border border-slate-800 bg-[#050810]">
              <img
                ref={imgRef}
                src={previewUrl}
                alt={cameraLabel}
                onLoad={drawBoundingBoxes}
                referrerPolicy="no-referrer"
                className="block max-h-[420px] w-full object-contain"
              />
              <canvas
                ref={canvasRef}
                className="pointer-events-none absolute inset-0 h-full w-full"
              />
              {isAnalyzing && (
                <div className="absolute inset-0 flex items-center justify-center bg-[#050810]/70 backdrop-blur-xs">
                  <div className="flex items-center gap-3 rounded-lg border border-slate-700 bg-[#0A1324] px-4 py-3 text-sm font-medium text-white">
                    <Loader2 className="h-4 w-4 animate-spin text-[#00E676]" />
                    Running Gemini Vision Vehicle Detection...
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Sample Feed Switcher */}
          <div className="space-y-2 pt-1">
            <p className="text-xs font-medium text-slate-400">
              Sample Traffic Camera Presets
            </p>
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-3">
              {SAMPLE_SCENES.map((scene) => (
                <button
                  key={scene.id}
                  type="button"
                  disabled={isAnalyzing}
                  onClick={() => void analyzeImageUrl(scene.url, scene.label)}
                  className={`flex items-center gap-2.5 rounded-lg border p-2 text-left transition-colors ${
                    cameraLabel === scene.label && !videoSrc
                      ? 'border-[#00E676]/60 bg-[#00E676]/10'
                      : 'border-slate-800 bg-[#070D19] hover:border-slate-700'
                  }`}
                >
                  <img
                    src={scene.url}
                    alt={scene.label}
                    referrerPolicy="no-referrer"
                    className="h-10 w-16 shrink-0 rounded object-cover"
                  />
                  <span className="line-clamp-2 text-xs font-medium text-slate-200">
                    {scene.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side: Charts + AI Scene Assessment */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
            <h2 className="font-display text-base font-semibold text-white">
              Vehicle Class Distribution
            </h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-1">
              <div className="h-52">
                <Bar
                  data={barChartData}
                  options={{
                    ...DARK_CHART_OPTIONS_BASE,
                    plugins: { ...DARK_CHART_OPTIONS_BASE.plugins, legend: { display: false } },
                  }}
                />
              </div>
              <div className="h-48">
                <Doughnut
                  data={doughnutData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'right',
                        labels: { color: '#CBD5E1', boxWidth: 10, font: { size: 11 } },
                      },
                      tooltip: DARK_CHART_OPTIONS_BASE.plugins.tooltip,
                    },
                  }}
                />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
            <h2 className="font-display text-base font-semibold text-white">
              AI Scene Assessment
            </h2>
            {analysis ? (
              <div className="mt-3 space-y-3">
                <div className="flex flex-wrap items-center gap-3 text-xs">
                  <span
                    className={`font-semibold ${DENSITY_META[analysis.densityLevel].textClass}`}
                  >
                    {DENSITY_META[analysis.densityLevel].label} ({analysis.densityScore}%)
                  </span>
                  <span aria-hidden="true" className="text-slate-600">
                    ·
                  </span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    Est. Speed: {analysis.estimatedAvgSpeedKmh} km/h
                  </span>
                  <span aria-hidden="true" className="text-slate-600">
                    ·
                  </span>
                  <span className="font-mono text-slate-400 tabular-nums">
                    {formatTimeShort(analysis.timestamp)}
                  </span>
                </div>
                <p className="text-sm leading-relaxed text-slate-300">{analysis.summary}</p>
                {analysis.recommendations.length > 0 && (
                  <ul className="space-y-1.5 border-t border-slate-800 pt-3 text-xs text-slate-300">
                    {analysis.recommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono text-[#00E676]">{i + 1}.</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ) : (
              <p className="mt-2 text-sm text-slate-400">
                Click &ldquo;Analyze Current Feed&rdquo; or upload a traffic image/video to run
                real-time Gemini vision vehicle detection and bounding-box localization.
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Vision Detection Log */}
      {snapshot.recentVisionAnalyses.length > 0 && (
        <section className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <h2 className="font-display text-base font-semibold text-white">
            Saved AI Detection History
          </h2>
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 pr-4 font-medium">Feed</th>
                  <th className="px-3 py-2 font-medium">Density</th>
                  <th className="px-3 py-2 text-right font-medium">Cars</th>
                  <th className="px-3 py-2 text-right font-medium">Bikes</th>
                  <th className="px-3 py-2 text-right font-medium">Buses</th>
                  <th className="px-3 py-2 text-right font-medium">Trucks</th>
                  <th className="px-3 py-2 text-right font-medium">Autos</th>
                  <th className="pl-3 py-2 text-right font-medium">Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {snapshot.recentVisionAnalyses.slice(0, 6).map((item) => (
                  <tr key={item.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 pr-4 font-medium text-white">{item.cameraLabel}</td>
                    <td
                      className={`px-3 py-2.5 font-medium ${
                        DENSITY_META[item.densityLevel].textClass
                      }`}
                    >
                      {DENSITY_META[item.densityLevel].shortLabel} ({item.densityScore}%)
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {item.vehicles.cars}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {item.vehicles.bikes}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {item.vehicles.buses}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {item.vehicles.trucks}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-300">
                      {item.vehicles.autoRickshaws}
                    </td>
                    <td className="pl-3 py-2.5 text-right font-mono font-semibold tabular-nums text-[#00E676]">
                      {item.totalVehicles}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
