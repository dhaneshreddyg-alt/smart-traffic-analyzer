import { useCallback, useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  AlertCircle,
  ArrowRight,
  Clock,
  Loader2,
  Navigation,
  Route,
  Sparkles,
} from 'lucide-react';
import type { TrafficPredictionResponse, TrafficSnapshot } from '../types/traffic';
import { DENSITY_META, formatTimeShort } from '../utils/trafficFormat';

interface PredictionViewProps {
  snapshot: TrafficSnapshot;
  initialOriginId: string | null;
  initialDestinationId: string | null;
}

export default function PredictionView({
  snapshot,
  initialOriginId,
  initialDestinationId,
}: PredictionViewProps) {
  const [originId, setOriginId] = useState<string>(
    initialOriginId ?? snapshot.corridors[0]?.id ?? ''
  );
  const [destinationId, setDestinationId] = useState<string>(
    initialDestinationId ?? snapshot.corridors[1]?.id ?? ''
  );
  const [loading, setLoading] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [prediction, setPrediction] = useState<TrafficPredictionResponse | null>(null);
  const [selectedRouteIndex, setSelectedRouteIndex] = useState<number>(0);

  const mapRef = useRef<HTMLDivElement | null>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const routeLayerRef = useRef<L.LayerGroup | null>(null);

  const runPrediction = useCallback(
    async (orig: string, dest: string) => {
      setLoading(true);
      setErrorMsg(null);
      try {
        const res = await fetch('/api/predict-traffic', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ originId: orig, destinationId: dest }),
        });
        const data = await res.json();
        if (!res.ok) {
          throw new Error(data.error || 'Failed to generate AI traffic prediction.');
        }
        setPrediction(data as TrafficPredictionResponse);
        setSelectedRouteIndex(0);
      } catch (err) {
        setErrorMsg(err instanceof Error ? err.message : 'Prediction service failed.');
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    if (initialOriginId) setOriginId(initialOriginId);
    if (initialDestinationId) setDestinationId(initialDestinationId);
  }, [initialOriginId, initialDestinationId]);

  useEffect(() => {
    if (!prediction && !loading && originId && destinationId) {
      void runPrediction(originId, destinationId);
    }
  }, [prediction, loading, originId, destinationId, runPrediction]);

  useEffect(() => {
    if (!mapRef.current || leafletMapRef.current) return;
    const map = L.map(mapRef.current, {
      center: [12.9616, 77.6146],
      zoom: 12,
      zoomControl: true,
    });
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);
    routeLayerRef.current = L.layerGroup().addTo(map);
    leafletMapRef.current = map;

    return () => {
      map.remove();
      leafletMapRef.current = null;
      routeLayerRef.current = null;
    };
  }, []);

  useEffect(() => {
    const group = routeLayerRef.current;
    if (!group) return;
    group.clearLayers();

    // Draw muted background corridors
    snapshot.corridors.forEach((c) => {
      L.polyline(c.coordinates, {
        color: '#334155',
        weight: 3,
        opacity: 0.45,
      }).addTo(group);
    });

    const activeRoute = prediction?.recommendedRoutes[selectedRouteIndex];
    if (activeRoute) {
      const corridorMap = new Map(snapshot.corridors.map((c) => [c.id, c]));
      const color = activeRoute.isFastest ? '#00E676' : '#38BDF8';

      activeRoute.corridorIds.forEach((cid) => {
        const corridor = corridorMap.get(cid);
        if (!corridor) return;
        L.polyline(corridor.coordinates, {
          color,
          weight: 7,
          opacity: 0.95,
          lineCap: 'round',
        }).addTo(group);
      });
    }
  }, [prediction, selectedRouteIndex, snapshot.corridors]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">AI Traffic Forecasting · Gemini 4</span>
            <span aria-hidden="true">·</span>
            <span>30m & 60m Horizon + Fastest Route Engine</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            AI-Based Traffic Prediction & Routing
          </h1>
        </div>

        {/* Route Query Controls */}
        <div className="flex flex-wrap items-end gap-3 rounded-xl border border-slate-800 bg-[#0A1324] p-3">
          <div>
            <label htmlFor="pred-origin" className="mb-1 block text-xs text-slate-400">
              Origin
            </label>
            <select
              id="pred-origin"
              value={originId}
              onChange={(e) => setOriginId(e.target.value)}
              className="rounded-lg border border-slate-700 bg-[#070D19] px-3 py-1.5 text-xs text-white focus:border-[#00E676] focus:outline-none"
            >
              {snapshot.corridors.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="pred-dest" className="mb-1 block text-xs text-slate-400">
              Destination
            </label>
            <select
              id="pred-dest"
              value={destinationId}
              onChange={(e) => setDestinationId(e.target.value)}
              className="rounded-lg border border-slate-700 bg-[#070D19] px-3 py-1.5 text-xs text-white focus:border-[#00E676] focus:outline-none"
            >
              {snapshot.corridors.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <button
            type="button"
            disabled={loading}
            onClick={() => void runPrediction(originId, destinationId)}
            className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-4 py-1.5 text-xs font-semibold text-[#04120B] transition-colors hover:bg-[#1FF58A] disabled:opacity-50 whitespace-nowrap"
          >
            {loading ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                Forecasting...
              </>
            ) : (
              <>
                <Sparkles className="h-3.5 w-3.5" />
                Run AI Forecast
              </>
            )}
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="flex items-center gap-2.5 rounded-xl border border-[#EF4444]/40 bg-[#EF4444]/10 p-4 text-sm text-red-200">
          <AlertCircle className="h-4 w-4 shrink-0 text-[#EF4444]" />
          <span>{errorMsg}</span>
        </div>
      )}

      {loading && !prediction ? (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {[0, 1].map((n) => (
            <div
              key={n}
              className="h-64 animate-pulse rounded-xl border border-slate-800 bg-[#0A1324] p-6"
            />
          ))}
        </div>
      ) : prediction ? (
        <>
          {/* AI Outlook Summary */}
          <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h2 className="font-display text-base font-semibold text-white">
                Network Congestion Outlook
              </h2>
              <span className="font-mono text-xs text-slate-400 tabular-nums">
                Generated {formatTimeShort(prediction.generatedAt)}
              </span>
            </div>
            <p className="mt-2 text-sm leading-relaxed text-slate-300">
              {prediction.networkOutlookSummary}
            </p>
          </div>

          {/* Alternative Routes + Interactive Route Map */}
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
            <div className="space-y-4 lg:col-span-6">
              <div className="flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold text-white">
                  Recommended Fastest & Alternative Routes
                </h2>
                <span className="text-xs text-slate-400">
                  {prediction.originName} <ArrowRight className="inline h-3 w-3" />{' '}
                  {prediction.destinationName}
                </span>
              </div>

              <div className="space-y-3">
                {prediction.recommendedRoutes.map((route, idx) => {
                  const meta = DENSITY_META[route.densityLevel];
                  const isSelected = selectedRouteIndex === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedRouteIndex(idx)}
                      className={`w-full rounded-xl border p-4 text-left transition-colors ${
                        isSelected
                          ? 'border-[#00E676] bg-[#0B1D1C]'
                          : 'border-slate-800 bg-[#0A1324] hover:border-slate-700'
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2 text-xs">
                            <span
                              className={`font-semibold ${
                                route.isFastest ? 'text-[#00E676]' : 'text-sky-400'
                              }`}
                            >
                              {route.isFastest ? 'Fastest Recommended Route' : 'Alternative Route'}
                            </span>
                            <span aria-hidden="true" className="text-slate-600">
                              ·
                            </span>
                            <span className={meta.textClass}>{meta.label}</span>
                          </div>
                          <h3 className="mt-1 font-display text-base font-semibold text-white">
                            {route.routeName}
                          </h3>
                        </div>

                        <div className="text-right font-mono tabular-nums">
                          <p className="text-lg font-bold text-white">
                            {route.estimatedTimeMin} min
                          </p>
                          <p className="text-xs text-[#00E676]">
                            {route.timeSavedMin > 0
                              ? `Saves ${route.timeSavedMin} min`
                              : `${route.distanceKm} km`}
                          </p>
                        </div>
                      </div>

                      <p className="mt-2 text-xs text-slate-400">
                        Path: {route.corridorNames.join(' → ')} ({route.distanceKm} km)
                      </p>
                      <p className="mt-1.5 text-xs leading-relaxed text-slate-300">
                        {route.rationale}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-col space-y-4 rounded-xl border border-slate-800/90 bg-[#0A1324] p-4 lg:col-span-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Route className="h-4 w-4 text-[#00E676]" />
                  <h2 className="font-display text-base font-semibold text-white">
                    Route Path Overlay
                  </h2>
                </div>
                <span className="text-xs text-slate-400">
                  {prediction.recommendedRoutes[selectedRouteIndex]?.routeName}
                </span>
              </div>
              <div
                ref={mapRef}
                className="h-80 w-full flex-1 overflow-hidden rounded-lg border border-slate-800"
              />
              {prediction.signalAdvisories.length > 0 && (
                <div className="rounded-lg border border-slate-800 bg-[#070D19] p-3.5">
                  <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-white">
                    <Navigation className="h-3.5 w-3.5 text-[#00E676]" />
                    AI Corridor & Signal Advisories
                  </p>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {prediction.signalAdvisories.map((adv, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="font-mono text-[#00E676]">{i + 1}.</span>
                        <span>{adv}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>

          {/* 30-Minute & 60-Minute Forecast Matrix */}
          <section className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
            <div className="mb-4 flex items-center gap-2">
              <Clock className="h-4 w-4 text-[#00E676]" />
              <h2 className="font-display text-lg font-semibold text-white">
                30-Minute & 1-Hour Congestion Forecast
              </h2>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead>
                  <tr className="border-b border-slate-800 text-xs text-slate-400">
                    <th className="py-2.5 pr-4 font-medium">Corridor</th>
                    <th className="px-3 py-2.5 font-medium">Current</th>
                    <th className="px-3 py-2.5 font-medium">Next 30 Min</th>
                    <th className="px-3 py-2.5 font-medium">Next 1 Hour</th>
                    <th className="px-3 py-2.5 text-right font-medium">Congestion Risk</th>
                    <th className="pl-4 py-2.5 font-medium">Predicted Hotspot Driver</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {prediction.forecasts.map((f, idx) => (
                    <tr key={idx} className="hover:bg-slate-800/30">
                      <td className="py-3 pr-4 font-medium text-white">{f.corridorName}</td>
                      <td className={`px-3 py-3 font-medium ${DENSITY_META[f.currentDensityLevel].textClass}`}>
                        {DENSITY_META[f.currentDensityLevel].shortLabel}
                      </td>
                      <td className="px-3 py-3 font-mono tabular-nums">
                        <span className={DENSITY_META[f.forecast30mLevel].textClass}>
                          {DENSITY_META[f.forecast30mLevel].shortLabel}
                        </span>{' '}
                        <span className="text-slate-400">({f.forecast30mSpeedKmh} km/h)</span>
                      </td>
                      <td className="px-3 py-3 font-mono tabular-nums">
                        <span className={DENSITY_META[f.forecast60mLevel].textClass}>
                          {DENSITY_META[f.forecast60mLevel].shortLabel}
                        </span>{' '}
                        <span className="text-slate-400">({f.forecast60mSpeedKmh} km/h)</span>
                      </td>
                      <td className="px-3 py-3 text-right font-mono font-semibold tabular-nums text-white">
                        {f.congestionProbabilityPct}%
                      </td>
                      <td className="pl-4 py-3 text-xs text-slate-300">{f.hotspotWarning}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      ) : null}
    </div>
  );
}
