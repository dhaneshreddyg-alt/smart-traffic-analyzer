import { useState } from 'react';
import {
  Activity,
  ArrowRight,
  Camera,
  Car,
  Gauge,
  MapPin,
  Navigation,
  TrafficCone,
} from 'lucide-react';
import type { TrafficSnapshot } from '../types/traffic';
import { DENSITY_META, VEHICLE_LABELS, formatNumber, formatTimeShort } from '../utils/trafficFormat';

export type NavTab =
  | 'home'
  | 'live-traffic'
  | 'vehicle-detection'
  | 'analytics'
  | 'prediction'
  | 'signals'
  | 'reports';

interface HomeDashboardProps {
  snapshot: TrafficSnapshot;
  onNavigate: (tab: NavTab) => void;
  onQuickRoutePredict: (originId: string, destinationId: string) => void;
  onInspectCameraSample: (sampleUrl: string, label: string) => void;
}

const CAMERA_FEEDS = [
  {
    id: 'cam-highway',
    label: 'Outer Ring Express Cam 04',
    corridor: 'East Tech Belt',
    url: '/src/assets/images/traffic_cam_highway_1795507185041.jpg',
  },
  {
    id: 'cam-junction',
    label: 'Trinity Circle Junction Cam 01',
    corridor: 'Central Business District',
    url: '/src/assets/images/traffic_cam_junction_1795507185390.jpg',
  },
  {
    id: 'cam-congestion',
    label: 'Silk Board Overpass Cam 09',
    corridor: 'South Arterial',
    url: '/src/assets/images/traffic_cam_congestion_1795507185977.jpg',
  },
];

export default function HomeDashboard({
  snapshot,
  onNavigate,
  onQuickRoutePredict,
  onInspectCameraSample,
}: HomeDashboardProps) {
  const [originId, setOriginId] = useState(snapshot.corridors[0]?.id ?? '');
  const [destinationId, setDestinationId] = useState(snapshot.corridors[1]?.id ?? '');

  const densityInfo = DENSITY_META[snapshot.summary.networkDensityLevel];
  const topCorridors = [...snapshot.corridors]
    .sort((a, b) => b.densityScore - a.densityScore)
    .slice(0, 6);

  return (
    <div className="space-y-8">
      {/* Hero Operations Header */}
      <section className="rounded-xl border border-slate-800/90 bg-gradient-to-br from-[#0A1324] via-[#0B172C] to-[#060B15] p-6 sm:p-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
          <div className="space-y-4 lg:col-span-7">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400">
              <span className="text-[#00E676] font-medium">Simulated Sensor Grid</span>
              <span aria-hidden="true">·</span>
              <span>{snapshot.corridors.length} Urban Corridors</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">
                Updated {formatTimeShort(snapshot.generatedAt)}
              </span>
            </div>
            <h1 className="font-display text-3xl font-bold tracking-tight text-white sm:text-4xl [text-wrap:balance]">
              Real-Time Urban Traffic Intelligence and Fastest Route Control
            </h1>
            <p className="max-w-2xl text-sm leading-relaxed text-slate-300 sm:text-base">
              Monitor corridor congestion, count multi-class vehicles with AI vision, optimize
              adaptive signal timers, and forecast bottlenecks 60 minutes ahead.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1">
              <button
                type="button"
                onClick={() => onNavigate('live-traffic')}
                className="inline-flex items-center gap-2 rounded-lg bg-[#00E676] px-4 py-2.5 text-sm font-semibold text-[#04120B] transition-colors hover:bg-[#1FF58A] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00E676] whitespace-nowrap shrink-0"
              >
                <MapPin className="h-4 w-4" />
                Open Live Traffic Map
              </button>
              <button
                type="button"
                onClick={() => onNavigate('vehicle-detection')}
                className="inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-[#0D1A30] px-4 py-2.5 text-sm font-medium text-slate-100 transition-colors hover:border-[#00E676]/60 hover:text-white focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#00E676] whitespace-nowrap shrink-0"
              >
                <Camera className="h-4 w-4 text-[#00E676]" />
                Analyze Traffic Feed
              </button>
            </div>
          </div>

          {/* Quick Fastest Route Finder */}
          <div className="rounded-xl border border-slate-800 bg-[#080F1D] p-5 lg:col-span-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-base font-semibold text-white">
                Fastest Route Finder
              </h2>
              <span className="text-xs text-slate-400">AI Corridor Routing</span>
            </div>
            <div className="space-y-3">
              <div>
                <label
                  htmlFor="home-origin"
                  className="mb-1 block text-xs font-medium text-slate-400"
                >
                  Origin Corridor
                </label>
                <select
                  id="home-origin"
                  value={originId}
                  onChange={(e) => setOriginId(e.target.value)}
                  className="w-full rounded-lg border border-slate-700/80 bg-[#0D172B] px-3 py-2 text-sm text-slate-100 focus:border-[#00E676] focus:outline-none"
                >
                  {snapshot.corridors.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.zone})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label
                  htmlFor="home-destination"
                  className="mb-1 block text-xs font-medium text-slate-400"
                >
                  Destination Corridor
                </label>
                <select
                  id="home-destination"
                  value={destinationId}
                  onChange={(e) => setDestinationId(e.target.value)}
                  className="w-full rounded-lg border border-slate-700/80 bg-[#0D172B] px-3 py-2 text-sm text-slate-100 focus:border-[#00E676] focus:outline-none"
                >
                  {snapshot.corridors.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.zone})
                    </option>
                  ))}
                </select>
              </div>
              <button
                type="button"
                onClick={() => onQuickRoutePredict(originId, destinationId)}
                className="mt-1 inline-flex w-full items-center justify-center gap-2 rounded-lg border border-[#00E676]/40 bg-[#00E676]/12 px-4 py-2.5 text-sm font-semibold text-[#00E676] transition-colors hover:bg-[#00E676]/20 whitespace-nowrap"
              >
                <Navigation className="h-4 w-4" />
                Find Fastest Route & Predict
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Primary 4-Column KPI Strip */}
      <section aria-label="Network Key Metrics" className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Vehicles Detected</span>
            <Car className="h-4 w-4 text-[#00E676]" />
          </div>
          <p className="mt-2 font-mono text-3xl font-bold tracking-tight text-white tabular-nums">
            {formatNumber(snapshot.summary.totalVehiclesDetected)}
          </p>
          <p className="mt-2 text-xs text-slate-400 tabular-nums">
            {formatNumber(snapshot.summary.vehicleTotals.cars)} cars ·{' '}
            {formatNumber(snapshot.summary.vehicleTotals.bikes)} bikes ·{' '}
            {formatNumber(snapshot.summary.vehicleTotals.autoRickshaws)} autos
          </p>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Current Traffic Density</span>
            <Gauge className="h-4 w-4 text-[#EAB308]" />
          </div>
          <div className="mt-2 flex items-baseline gap-2.5">
            <p className="font-mono text-3xl font-bold tracking-tight text-white tabular-nums">
              {snapshot.summary.networkDensityScore}%
            </p>
            <span className={`text-xs font-semibold ${densityInfo.textClass}`}>
              {densityInfo.label}
            </span>
          </div>
          <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${snapshot.summary.networkDensityScore}%`,
                backgroundColor: densityInfo.hex,
              }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Traffic Signals Monitored</span>
            <Activity className="h-4 w-4 text-[#00E676]" />
          </div>
          <p className="mt-2 font-mono text-3xl font-bold tracking-tight text-white tabular-nums">
            {snapshot.summary.activeSignalsCount}
          </p>
          <p className="mt-2 text-xs text-slate-400 tabular-nums">
            {snapshot.signals.filter((s) => s.mode === 'ai_adaptive').length} AI Adaptive ·{' '}
            {snapshot.signals.filter((s) => s.currentPhase === 'green').length} Green phase active
          </p>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Congested Roads</span>
            <TrafficCone className="h-4 w-4 text-[#EF4444]" />
          </div>
          <div className="mt-2 flex items-baseline gap-2.5">
            <p className="font-mono text-3xl font-bold tracking-tight text-white tabular-nums">
              {snapshot.summary.congestedRoadsCount}
            </p>
            <span className="text-xs text-slate-400">
              of {snapshot.corridors.length} corridors
            </span>
          </div>
          <p className="mt-2 text-xs text-slate-400 tabular-nums">
            Network avg speed: <span className="text-slate-200">{snapshot.summary.networkAvgSpeedKmh} km/h</span>
          </p>
        </div>
      </section>

      {/* Live Traffic Status Cards */}
      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-white">
              Live Traffic Status Cards
            </h2>
            <p className="text-sm text-slate-400">
              Highest-load urban corridors with simulated sensor counts and flow speed
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('live-traffic')}
            className="inline-flex items-center gap-1.5 text-sm font-medium text-[#00E676] hover:underline whitespace-nowrap shrink-0"
          >
            View All Corridors on Map
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {topCorridors.map((corridor) => {
            const meta = DENSITY_META[corridor.densityLevel];
            return (
              <div
                key={corridor.id}
                className="flex flex-col justify-between rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 transition-colors hover:border-slate-700"
              >
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs text-slate-400">{corridor.zone}</p>
                      <h3 className="mt-0.5 font-display text-base font-semibold text-white">
                        {corridor.name}
                      </h3>
                    </div>
                    <span className={`font-mono text-xs font-semibold ${meta.textClass} whitespace-nowrap`}>
                      {meta.label}
                    </span>
                  </div>

                  <div className="mt-4 grid grid-cols-3 gap-2 border-y border-slate-800/80 py-3">
                    <div>
                      <p className="text-xs text-slate-400">Vehicles</p>
                      <p className="mt-0.5 font-mono text-base font-semibold text-white tabular-nums">
                        {formatNumber(corridor.totalVehicles)}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Density</p>
                      <p className="mt-0.5 font-mono text-base font-semibold text-white tabular-nums">
                        {corridor.densityScore}%
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-400">Avg Speed</p>
                      <p className="mt-0.5 font-mono text-base font-semibold text-white tabular-nums">
                        {corridor.avgSpeedKmh} km/h
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between gap-2 text-xs text-slate-400">
                  <span className="truncate">
                    {corridor.incidentNote ?? `${corridor.lanes} lanes · Normal progression`}
                  </span>
                  <button
                    type="button"
                    onClick={() => onNavigate('signals')}
                    className="font-medium text-slate-200 hover:text-[#00E676] whitespace-nowrap shrink-0"
                  >
                    Signal Timing
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Camera Feed Quick Vision Launcher + Modal Split */}
      <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-4">
          <h2 className="font-display text-lg font-semibold text-white">
            Network Vehicle Mix
          </h2>
          <p className="mt-1 text-xs text-slate-400">
            Simulated live counts across 5 tracked classes
          </p>
          <div className="mt-5 space-y-3.5">
            {VEHICLE_LABELS.map((item) => {
              const count = snapshot.summary.vehicleTotals[item.key];
              const pct =
                snapshot.summary.totalVehiclesDetected > 0
                  ? Math.round((count / snapshot.summary.totalVehiclesDetected) * 100)
                  : 0;
              return (
                <div key={item.key} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-200 font-medium">{item.label}</span>
                    <span className="font-mono text-slate-300 tabular-nums">
                      {formatNumber(count)} ({pct}%)
                    </span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{ width: `${pct}%`, backgroundColor: item.color }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-semibold text-white">
                Traffic Camera Feeds for AI Detection
              </h2>
              <p className="text-xs text-slate-400">
                Select any feed to run real-time Gemini multimodal vehicle detection and bounding-box counting
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('vehicle-detection')}
              className="text-xs font-medium text-[#00E676] hover:underline whitespace-nowrap shrink-0"
            >
              Upload Custom Image / Video
            </button>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            {CAMERA_FEEDS.map((feed) => (
              <button
                key={feed.id}
                type="button"
                onClick={() => onInspectCameraSample(feed.url, feed.label)}
                className="group overflow-hidden rounded-lg border border-slate-800 bg-[#070D19] text-left transition-colors hover:border-[#00E676]/60 focus-visible:outline-2 focus-visible:outline-[#00E676]"
              >
                <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                  <img
                    src={feed.url}
                    alt={feed.label}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <span className="absolute bottom-2 left-2.5 text-xs font-medium text-[#00E676]">
                    Run AI Vision
                  </span>
                </div>
                <div className="p-3">
                  <p className="truncate text-sm font-semibold text-white">{feed.label}</p>
                  <p className="mt-0.5 text-xs text-slate-400">{feed.corridor}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
