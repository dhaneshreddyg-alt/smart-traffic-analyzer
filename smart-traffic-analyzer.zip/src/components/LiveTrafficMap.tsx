import { useEffect, useMemo, useRef, useState } from 'react';
import L from 'leaflet';
import { AlertTriangle, Compass, Layers, Radio } from 'lucide-react';
import type { DensityLevel, RoadCorridor, TrafficSnapshot } from '../types/traffic';
import { DENSITY_META, VEHICLE_LABELS, formatNumber, formatTimeShort } from '../utils/trafficFormat';

interface LiveTrafficMapProps {
  snapshot: TrafficSnapshot;
}

export default function LiveTrafficMap({ snapshot }: LiveTrafficMapProps) {
  const mapContainerRef = useRef<HTMLDivElement | null>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const layerGroupRef = useRef<L.LayerGroup | null>(null);

  const [filterLevel, setFilterLevel] = useState<'all' | DensityLevel>('all');
  const [selectedCorridorId, setSelectedCorridorId] = useState<string>(
    snapshot.corridors[0]?.id ?? ''
  );

  const filteredCorridors = useMemo(() => {
    if (filterLevel === 'all') return snapshot.corridors;
    return snapshot.corridors.filter((c) => c.densityLevel === filterLevel);
  }, [snapshot.corridors, filterLevel]);

  const selectedCorridor: RoadCorridor | undefined = useMemo(() => {
    return (
      snapshot.corridors.find((c) => c.id === selectedCorridorId) ??
      filteredCorridors[0] ??
      snapshot.corridors[0]
    );
  }, [snapshot.corridors, filteredCorridors, selectedCorridorId]);

  const linkedSignal = useMemo(() => {
    if (!selectedCorridor) return undefined;
    return snapshot.signals.find((s) => s.corridorId === selectedCorridor.id);
  }, [snapshot.signals, selectedCorridor]);

  // Initialize Leaflet map once
  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [12.9616, 77.6146],
      zoom: 12,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; OpenStreetMap contributors &copy; CARTO',
      subdomains: 'abcd',
      maxZoom: 19,
    }).addTo(map);

    const group = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;
    layerGroupRef.current = group;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
      layerGroupRef.current = null;
    };
  }, []);

  // Re-render corridor polylines and signal markers whenever snapshot or filter changes
  useEffect(() => {
    const group = layerGroupRef.current;
    const map = mapInstanceRef.current;
    if (!group || !map) return;

    group.clearLayers();

    filteredCorridors.forEach((corridor) => {
      const meta = DENSITY_META[corridor.densityLevel];
      const isSelected = selectedCorridor?.id === corridor.id;

      // Subtle outer glow polyline for selected or severe corridors
      if (isSelected || corridor.densityLevel === 'severe') {
        L.polyline(corridor.coordinates, {
          color: meta.hex,
          weight: isSelected ? 12 : 9,
          opacity: isSelected ? 0.35 : 0.2,
          lineCap: 'round',
        }).addTo(group);
      }

      const line = L.polyline(corridor.coordinates, {
        color: meta.hex,
        weight: isSelected ? 6 : 4.5,
        opacity: 0.95,
        lineCap: 'round',
      }).addTo(group);

      line.bindTooltip(
        `<div style="font-family: Plus Jakarta Sans, sans-serif; min-width: 170px;">
          <div style="font-weight: 700; margin-bottom: 2px;">${corridor.name}</div>
          <div style="font-size: 12px; color: ${meta.hex}; font-weight: 600;">${meta.label} (${corridor.densityScore}%)</div>
          <div style="font-size: 11px; color: #cbd5e1; margin-top: 2px;">${corridor.totalVehicles} vehicles · ${corridor.avgSpeedKmh} km/h</div>
        </div>`,
        { sticky: true }
      );

      line.on('click', () => {
        setSelectedCorridorId(corridor.id);
      });
    });

    snapshot.signals.forEach((sig) => {
      const phaseColor =
        sig.currentPhase === 'green'
          ? '#22C55E'
          : sig.currentPhase === 'yellow'
          ? '#EAB308'
          : '#EF4444';

      const marker = L.circleMarker([sig.lat, sig.lng], {
        radius: 7,
        fillColor: phaseColor,
        color: '#050810',
        weight: 2,
        opacity: 1,
        fillOpacity: 1,
      }).addTo(group);

      marker.bindPopup(
        `<div style="font-family: Plus Jakarta Sans, sans-serif;">
          <div style="font-weight: 700;">${sig.intersectionName}</div>
          <div style="font-size: 12px; margin-top: 4px;">Phase: <strong style="color:${phaseColor}; text-transform: uppercase;">${sig.currentPhase}</strong> (${sig.remainingSec}s)</div>
          <div style="font-size: 12px; color: #94a3b8; margin-top: 2px;">Queue: ${sig.queueLengthVehicles} vehicles · ${sig.mode === 'ai_adaptive' ? 'AI Adaptive' : 'Manual'}</div>
        </div>`
      );

      marker.on('click', () => {
        setSelectedCorridorId(sig.corridorId);
      });
    });
  }, [filteredCorridors, snapshot.signals, selectedCorridor]);

  return (
    <div className="space-y-6">
      {/* Header & Density Filter Bar */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">Simulated Sensor Grid</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">
              {formatTimeShort(snapshot.generatedAt)}
            </span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            Live Traffic Monitoring Map
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg border border-slate-800 bg-[#0A1324] p-1">
          {(
            [
              { id: 'all', label: 'All Roads' },
              { id: 'low', label: 'Low' },
              { id: 'moderate', label: 'Moderate' },
              { id: 'heavy', label: 'Heavy' },
              { id: 'severe', label: 'Severe' },
            ] as const
          ).map((item) => (
            <button
              key={item.id}
              type="button"
              onClick={() => setFilterLevel(item.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                filterLevel === item.id
                  ? 'bg-[#00E676] text-[#04120B]'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Color Legend Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-800/90 bg-[#0A1324] px-5 py-3">
        <div className="flex flex-wrap items-center gap-5 text-xs">
          <span className="flex items-center gap-2 font-medium text-slate-300">
            <Layers className="h-3.5 w-3.5 text-slate-400" />
            Density Legend:
          </span>
          {(['low', 'moderate', 'heavy', 'severe'] as DensityLevel[]).map((level) => (
            <span key={level} className="flex items-center gap-2 text-slate-200">
              <span
                className="inline-block h-2.5 w-5 rounded-sm"
                style={{ backgroundColor: DENSITY_META[level].hex }}
              />
              <span>{DENSITY_META[level].label}</span>
            </span>
          ))}
        </div>
        <span className="text-xs text-slate-400 font-mono tabular-nums">
          Showing {filteredCorridors.length} / {snapshot.corridors.length} corridors
        </span>
      </div>

      {/* Main Split: Interactive Leaflet Map + Corridor Inspector */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="overflow-hidden rounded-xl border border-slate-800/90 bg-[#0A1324] lg:col-span-8">
          <div
            ref={mapContainerRef}
            className="h-[440px] w-full sm:h-[520px]"
            aria-label="Interactive traffic density map"
          />
        </div>

        {/* Selected Corridor Inspector */}
        <div className="flex flex-col justify-between space-y-5 rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-4">
          {selectedCorridor ? (
            <>
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs text-slate-400">{selectedCorridor.zone}</p>
                    <h2 className="mt-0.5 font-display text-lg font-semibold text-white">
                      {selectedCorridor.name}
                    </h2>
                  </div>
                  <span
                    className={`font-mono text-xs font-semibold ${
                      DENSITY_META[selectedCorridor.densityLevel].textClass
                    } whitespace-nowrap`}
                  >
                    {DENSITY_META[selectedCorridor.densityLevel].label}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 rounded-lg border border-slate-800 bg-[#070D19] p-3.5">
                  <div>
                    <p className="text-xs text-slate-400">Density Score</p>
                    <p className="mt-0.5 font-mono text-xl font-bold text-white tabular-nums">
                      {selectedCorridor.densityScore}%
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Avg Speed / Limit</p>
                    <p className="mt-0.5 font-mono text-xl font-bold text-white tabular-nums">
                      {selectedCorridor.avgSpeedKmh}
                      <span className="text-xs font-normal text-slate-400">
                        /{selectedCorridor.freeFlowSpeedKmh} km/h
                      </span>
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Active Vehicles</p>
                    <p className="mt-0.5 font-mono text-lg font-semibold text-[#00E676] tabular-nums">
                      {formatNumber(selectedCorridor.totalVehicles)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Geometry</p>
                    <p className="mt-0.5 font-mono text-lg font-semibold text-slate-200 tabular-nums">
                      {selectedCorridor.lengthKm} km · {selectedCorridor.lanes}L
                    </p>
                  </div>
                </div>

                {/* Vehicle Class Breakdown */}
                <div className="space-y-2">
                  <p className="text-xs font-medium text-slate-300">
                    Corridor Vehicle Breakdown
                  </p>
                  <div className="space-y-2">
                    {VEHICLE_LABELS.map((item) => (
                      <div
                        key={item.key}
                        className="flex items-center justify-between text-xs border-b border-slate-800/60 pb-1.5"
                      >
                        <span className="text-slate-300">{item.label}</span>
                        <span className="font-mono font-semibold text-white tabular-nums">
                          {formatNumber(selectedCorridor.vehicles[item.key])}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Linked Signal Status */}
                {linkedSignal && (
                  <div className="rounded-lg border border-slate-800 bg-[#070D19] p-3.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-300">
                        {linkedSignal.intersectionName}
                      </span>
                      <span
                        className={`font-mono text-xs font-bold uppercase ${
                          linkedSignal.currentPhase === 'green'
                            ? 'text-[#22C55E]'
                            : linkedSignal.currentPhase === 'yellow'
                            ? 'text-[#EAB308]'
                            : 'text-[#EF4444]'
                        }`}
                      >
                        {linkedSignal.currentPhase} · {linkedSignal.remainingSec}s
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-slate-400 tabular-nums">
                      Queue: {linkedSignal.queueLengthVehicles} vehicles ·{' '}
                      {linkedSignal.mode === 'ai_adaptive' ? 'AI Adaptive' : 'Manual'}
                    </p>
                  </div>
                )}
              </div>

              {selectedCorridor.incidentNote && (
                <div className="flex items-start gap-2.5 rounded-lg border border-[#F97316]/30 bg-[#F97316]/10 p-3 text-xs text-slate-200">
                  <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#F97316]" />
                  <span>{selectedCorridor.incidentNote}</span>
                </div>
              )}
            </>
          ) : (
            <p className="text-sm text-slate-400">
              Select a corridor on the map to inspect real-time metrics.
            </p>
          )}
        </div>
      </div>

      {/* Live Traffic Updates & Road Conditions Feed */}
      <section className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className="h-4 w-4 text-[#00E676]" />
            <h2 className="font-display text-lg font-semibold text-white">
              Traffic Updates & Road Conditions
            </h2>
          </div>
          <span className="text-xs text-slate-400">Click a row to focus map</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-slate-800 text-xs text-slate-400">
                <th className="py-2.5 pr-4 font-medium">Corridor</th>
                <th className="px-4 py-2.5 font-medium">Condition</th>
                <th className="px-4 py-2.5 text-right font-medium">Density</th>
                <th className="px-4 py-2.5 text-right font-medium">Avg Speed</th>
                <th className="px-4 py-2.5 text-right font-medium">Vehicles</th>
                <th className="pl-4 py-2.5 font-medium">Advisory</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {filteredCorridors.map((c) => {
                const meta = DENSITY_META[c.densityLevel];
                return (
                  <tr
                    key={c.id}
                    onClick={() => {
                      setSelectedCorridorId(c.id);
                      mapInstanceRef.current?.panTo(c.coordinates[0]);
                    }}
                    className={`cursor-pointer transition-colors hover:bg-slate-800/40 ${
                      selectedCorridor?.id === c.id ? 'bg-slate-800/30' : ''
                    }`}
                  >
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-2 font-medium text-white">
                        <Compass className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                        <span>{c.name}</span>
                      </div>
                    </td>
                    <td className={`px-4 py-3 font-medium ${meta.textClass}`}>
                      {meta.label}
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-200">
                      {c.densityScore}%
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-slate-200">
                      {c.avgSpeedKmh} km/h
                    </td>
                    <td className="px-4 py-3 text-right font-mono tabular-nums text-white font-semibold">
                      {formatNumber(c.totalVehicles)}
                    </td>
                    <td className="pl-4 py-3 text-xs text-slate-400">
                      {c.incidentNote ?? 'Steady green-wave flow'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
