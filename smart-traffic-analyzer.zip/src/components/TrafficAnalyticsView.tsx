import { useState } from 'react';
import { Bar, Line, Pie } from 'react-chartjs-2';
import { Clock, Flame, Gauge, TrendingUp } from 'lucide-react';
import type { ReportTimeframe, TrafficSnapshot } from '../types/traffic';
import {
  DARK_CHART_OPTIONS_BASE,
  DENSITY_META,
  VEHICLE_LABELS,
  formatNumber,
} from '../utils/trafficFormat';

interface TrafficAnalyticsViewProps {
  snapshot: TrafficSnapshot;
}

export default function TrafficAnalyticsView({ snapshot }: TrafficAnalyticsViewProps) {
  const [timeframe, setTimeframe] = useState<ReportTimeframe>('daily');

  const activeReport = snapshot.reports[timeframe];
  const sortedCorridors = [...snapshot.corridors].sort(
    (a, b) => b.densityScore - a.densityScore
  );
  const mostCongested = sortedCorridors[0];
  const peakHour = [...snapshot.hourlySeries].sort(
    (a, b) => b.totalVehicles - a.totalVehicles
  )[0];

  const barData = {
    labels: activeReport.labels,
    datasets: [
      {
        label: 'Vehicle Volume',
        data: activeReport.vehicleTotals,
        backgroundColor: '#00E676',
        borderRadius: 6,
      },
      {
        label: 'Congestion Index (%)',
        data: activeReport.congestionPct.map((p) =>
          Math.round((p / 100) * Math.max(...activeReport.vehicleTotals) * 0.6)
        ),
        backgroundColor: '#38BDF8',
        borderRadius: 6,
      },
    ],
  };

  const lineData = {
    labels: snapshot.hourlySeries.map((h) => h.hour),
    datasets: [
      {
        label: 'Hourly Vehicle Volume',
        data: snapshot.hourlySeries.map((h) => h.totalVehicles),
        borderColor: '#00E676',
        backgroundColor: 'rgba(0, 230, 118, 0.12)',
        fill: true,
        tension: 0.35,
        yAxisID: 'y',
      },
      {
        label: 'Avg Speed (km/h)',
        data: snapshot.hourlySeries.map((h) => h.avgSpeedKmh),
        borderColor: '#FACC15',
        backgroundColor: 'rgba(250, 204, 21, 0.08)',
        fill: false,
        tension: 0.35,
        yAxisID: 'y1',
      },
    ],
  };

  const pieData = {
    labels: VEHICLE_LABELS.map((v) => v.label),
    datasets: [
      {
        data: VEHICLE_LABELS.map((v) => activeReport.vehicleDistribution[v.key]),
        backgroundColor: VEHICLE_LABELS.map((v) => v.color),
        borderColor: '#0A1324',
        borderWidth: 2,
      },
    ],
  };

  return (
    <div className="space-y-6">
      {/* Header & Timeframe Switcher */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">Traffic Analysis</span>
            <span aria-hidden="true">·</span>
            <span>Simulated Historical & Corridor Telemetry</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            Traffic Density & Peak Hour Analytics
          </h1>
        </div>

        <div className="flex items-center gap-1 rounded-lg border border-slate-800 bg-[#0A1324] p-1 self-start">
          {(['daily', 'weekly', 'monthly'] as ReportTimeframe[]).map((tf) => (
            <button
              key={tf}
              type="button"
              onClick={() => setTimeframe(tf)}
              className={`rounded-md px-3.5 py-1.5 text-xs font-semibold capitalize transition-colors whitespace-nowrap ${
                timeframe === tf
                  ? 'bg-[#00E676] text-[#04120B]'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* 4 Summary Analytics Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Peak Traffic Hour</span>
            <Clock className="h-4 w-4 text-[#FACC15]" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
            {peakHour?.hour ?? '18:00'}
          </p>
          <p className="mt-1.5 text-xs text-slate-400 tabular-nums">
            {formatNumber(peakHour?.totalVehicles ?? 5240)} vehicles/hr ·{' '}
            {peakHour?.congestionPct ?? 93}% load
          </p>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Most Congested Road</span>
            <Flame className="h-4 w-4 text-[#EF4444]" />
          </div>
          <p className="mt-2 truncate font-display text-lg font-bold text-white">
            {mostCongested?.name ?? 'Outer Ring Express'}
          </p>
          <p className="mt-1.5 text-xs text-[#EF4444] font-mono tabular-nums">
            {mostCongested?.densityScore ?? 85}% density · {mostCongested?.avgSpeedKmh ?? 16} km/h
          </p>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Network Average Speed</span>
            <Gauge className="h-4 w-4 text-[#38BDF8]" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
            {snapshot.summary.networkAvgSpeedKmh} km/h
          </p>
          <p className="mt-1.5 text-xs text-slate-400">
            Across {snapshot.corridors.length} monitored arterials
          </p>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Selected Period Volume</span>
            <TrendingUp className="h-4 w-4 text-[#00E676]" />
          </div>
          <p className="mt-2 font-mono text-2xl font-bold text-white tabular-nums">
            {formatNumber(
              activeReport.vehicleTotals.reduce((acc, v) => acc + v, 0)
            )}
          </p>
          <p className="mt-1.5 text-xs capitalize text-slate-400">
            {timeframe} cumulative vehicle count
          </p>
        </div>
      </div>

      {/* Interactive Line Graph (Hourly Peak & Speed) + Pie Chart */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-8">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="font-display text-lg font-semibold text-white">
                Peak Traffic Hours & Speed Inverse Curve
              </h2>
              <p className="text-xs text-slate-400">
                24-hour flow profile showing morning (09:00) and evening (18:00) congestion peaks
              </p>
            </div>
          </div>
          <div className="h-72">
            <Line
              data={lineData}
              options={{
                ...DARK_CHART_OPTIONS_BASE,
                scales: {
                  x: DARK_CHART_OPTIONS_BASE.scales.x,
                  y: {
                    ...DARK_CHART_OPTIONS_BASE.scales.y,
                    position: 'left',
                    title: {
                      display: true,
                      text: 'Vehicles / hr',
                      color: '#94A3B8',
                      font: { size: 11 },
                    },
                  },
                  y1: {
                    position: 'right',
                    grid: { drawOnChartArea: false },
                    ticks: {
                      color: '#FACC15',
                      font: { family: '"JetBrains Mono", monospace', size: 11 },
                    },
                    title: {
                      display: true,
                      text: 'Speed (km/h)',
                      color: '#FACC15',
                      font: { size: 11 },
                    },
                  },
                },
              }}
            />
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-4">
          <h2 className="font-display text-lg font-semibold text-white">
            Vehicle Category Share
          </h2>
          <p className="mt-0.5 text-xs capitalize text-slate-400">
            {timeframe} modal distribution
          </p>
          <div className="mt-4 h-64">
            <Pie
              data={pieData}
              options={{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                  legend: {
                    position: 'bottom',
                    labels: { color: '#CBD5E1', boxWidth: 10, font: { size: 11 } },
                  },
                  tooltip: DARK_CHART_OPTIONS_BASE.plugins.tooltip,
                },
              }}
            />
          </div>
        </div>
      </div>

      {/* Bar Chart (Daily / Weekly / Monthly) + Ranked Congested Roads Table */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-6">
          <h2 className="font-display text-lg font-semibold text-white capitalize">
            {timeframe} Traffic Volume Comparison
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Vehicle throughput and normalized congestion load across {timeframe} intervals
          </p>
          <div className="mt-4 h-72">
            <Bar data={barData} options={DARK_CHART_OPTIONS_BASE} />
          </div>
        </div>

        <div className="rounded-xl border border-slate-800/90 bg-[#0A1324] p-5 lg:col-span-6">
          <h2 className="font-display text-lg font-semibold text-white">
            Most Congested Roads Ranking
          </h2>
          <p className="mt-0.5 text-xs text-slate-400">
            Sorted by real-time corridor density percentage
          </p>
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400">
                  <th className="py-2 pr-3 font-medium">Corridor</th>
                  <th className="px-3 py-2 font-medium">Status</th>
                  <th className="px-3 py-2 text-right font-medium">Density</th>
                  <th className="px-3 py-2 text-right font-medium">Speed</th>
                  <th className="pl-3 py-2 text-right font-medium">Vehicles</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70">
                {sortedCorridors.slice(0, 7).map((c) => {
                  const meta = DENSITY_META[c.densityLevel];
                  return (
                    <tr key={c.id} className="hover:bg-slate-800/30">
                      <td className="py-2.5 pr-3 font-medium text-white">{c.name}</td>
                      <td className={`px-3 py-2.5 font-medium ${meta.textClass}`}>
                        {meta.shortLabel}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                        {c.densityScore}%
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono tabular-nums text-slate-200">
                        {c.avgSpeedKmh} km/h
                      </td>
                      <td className="pl-3 py-2.5 text-right font-mono font-semibold tabular-nums text-white">
                        {formatNumber(c.totalVehicles)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
