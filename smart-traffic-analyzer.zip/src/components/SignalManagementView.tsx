import { useState } from 'react';
import { Check, Loader2, SlidersHorizontal, Sparkles } from 'lucide-react';
import type { SignalMode, TrafficSignal, TrafficSnapshot } from '../types/traffic';
import { DENSITY_META } from '../utils/trafficFormat';

interface SignalManagementViewProps {
  snapshot: TrafficSnapshot;
  onSignalUpdated: (updated: TrafficSnapshot) => void;
}

export default function SignalManagementView({
  snapshot,
  onSignalUpdated,
}: SignalManagementViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [savingId, setSavingId] = useState<string | null>(null);
  const [draftTimings, setDraftTimings] = useState<{
    greenSec: number;
    yellowSec: number;
    redSec: number;
  }>({ greenSec: 40, yellowSec: 4, redSec: 40 });
  const [statusFeedback, setStatusFeedback] = useState<string | null>(null);

  const submitSignalTiming = async (
    signalId: string,
    mode: SignalMode,
    timings: { greenSec: number; yellowSec: number; redSec: number }
  ) => {
    setSavingId(signalId);
    setStatusFeedback(null);
    try {
      const res = await fetch(`/api/signals/${signalId}/optimize`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mode, ...timings }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to update traffic signal timings.');
      }
      onSignalUpdated(data as TrafficSnapshot);
      setEditingId(null);
      setStatusFeedback(`Updated signal controller timing (${mode === 'ai_adaptive' ? 'AI Adaptive' : 'Manual'}).`);
    } catch (err) {
      setStatusFeedback(err instanceof Error ? err.message : 'Update failed.');
    } finally {
      setSavingId(null);
    }
  };

  const openEditor = (sig: TrafficSignal) => {
    setEditingId(sig.id);
    setDraftTimings({
      greenSec: sig.timings.greenSec,
      yellowSec: sig.timings.yellowSec,
      redSec: sig.timings.redSec,
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-[#00E676] font-medium">Signal Control Matrix</span>
            <span aria-hidden="true">·</span>
            <span>{snapshot.signals.length} Active Intersections</span>
          </div>
          <h1 className="mt-1 font-display text-2xl font-bold text-white sm:text-3xl">
            Traffic Signal Management Dashboard
          </h1>
        </div>
        {statusFeedback && (
          <div className="inline-flex items-center gap-2 rounded-lg border border-[#00E676]/40 bg-[#00E676]/10 px-3.5 py-2 text-xs text-[#00E676]">
            <Check className="h-3.5 w-3.5" />
            <span>{statusFeedback}</span>
          </div>
        )}
      </div>

      {/* Signal Grid */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
        {snapshot.signals.map((sig) => {
          const densityMeta = DENSITY_META[sig.densityLevel];
          const isEditing = editingId === sig.id;
          const isSaving = savingId === sig.id;

          return (
            <div
              key={sig.id}
              className="flex flex-col justify-between rounded-xl border border-slate-800/90 bg-[#0A1324] p-5"
            >
              <div className="space-y-4">
                {/* Top row: Intersection Name + Physical Signal Housing */}
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span>{sig.mode === 'ai_adaptive' ? 'AI Adaptive' : 'Manual Override'}</span>
                      <span aria-hidden="true">·</span>
                      <span className={densityMeta.textClass}>{densityMeta.label}</span>
                    </div>
                    <h2 className="mt-1 font-display text-lg font-semibold text-white">
                      {sig.intersectionName}
                    </h2>
                    <p className="mt-0.5 text-xs text-slate-400 tabular-nums">
                      Queue length: {sig.queueLengthVehicles} vehicles
                    </p>
                  </div>

                  {/* Real-Time Signal Head Housing + Countdown */}
                  <div className="flex items-center gap-3 rounded-lg border border-slate-700/80 bg-[#050810] px-3 py-2">
                    <div className="flex items-center gap-1.5">
                      <span
                        aria-label="Red signal"
                        className={`h-3.5 w-3.5 rounded-full transition-opacity ${
                          sig.currentPhase === 'red'
                            ? 'bg-[#EF4444] shadow-[0_0_10px_#EF4444]'
                            : 'bg-slate-800 opacity-35'
                        }`}
                      />
                      <span
                        aria-label="Yellow signal"
                        className={`h-3.5 w-3.5 rounded-full transition-opacity ${
                          sig.currentPhase === 'yellow'
                            ? 'bg-[#EAB308] shadow-[0_0_10px_#EAB308]'
                            : 'bg-slate-800 opacity-35'
                        }`}
                      />
                      <span
                        aria-label="Green signal"
                        className={`h-3.5 w-3.5 rounded-full transition-opacity ${
                          sig.currentPhase === 'green'
                            ? 'bg-[#22C55E] shadow-[0_0_10px_#22C55E]'
                            : 'bg-slate-800 opacity-35'
                        }`}
                      />
                    </div>
                    <div className="border-l border-slate-800 pl-2.5 text-right font-mono tabular-nums">
                      <p
                        className={`text-base font-bold leading-none ${
                          sig.currentPhase === 'green'
                            ? 'text-[#22C55E]'
                            : sig.currentPhase === 'yellow'
                            ? 'text-[#EAB308]'
                            : 'text-[#EF4444]'
                        }`}
                      >
                        {sig.remainingSec}s
                      </p>
                      <p className="mt-0.5 text-[10px] uppercase text-slate-400">
                        {sig.currentPhase}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Current vs AI Recommended Phase Timers */}
                <div className="grid grid-cols-2 gap-3 rounded-lg border border-slate-800 bg-[#070D19] p-3.5 text-xs">
                  <div>
                    <p className="font-medium text-slate-400">Active Cycle Timers</p>
                    <p className="mt-1.5 font-mono text-sm font-semibold text-white tabular-nums">
                      <span className="text-[#22C55E]">{sig.timings.greenSec}s G</span> ·{' '}
                      <span className="text-[#EAB308]">{sig.timings.yellowSec}s Y</span> ·{' '}
                      <span className="text-[#EF4444]">{sig.timings.redSec}s R</span>
                    </p>
                  </div>
                  <div>
                    <p className="font-medium text-[#00E676]">
                      AI Optimal (-{sig.aiRecommendedTimings.expectedWaitReductionPct}% wait)
                    </p>
                    <p className="mt-1.5 font-mono text-sm font-semibold text-slate-200 tabular-nums">
                      {sig.aiRecommendedTimings.greenSec}s G ·{' '}
                      {sig.aiRecommendedTimings.yellowSec}s Y ·{' '}
                      {sig.aiRecommendedTimings.redSec}s R
                    </p>
                  </div>
                </div>

                <p className="text-xs leading-relaxed text-slate-300">
                  {sig.aiRecommendedTimings.reason}
                </p>

                {/* Manual Timing Editor */}
                {isEditing && (
                  <div className="space-y-3 rounded-lg border border-slate-700 bg-[#070D19] p-3.5">
                    <div className="grid grid-cols-3 gap-3 text-xs">
                      <div>
                        <label className="mb-1 block text-[#22C55E]">Green (sec)</label>
                        <input
                          type="number"
                          min={10}
                          max={120}
                          value={draftTimings.greenSec}
                          onChange={(e) =>
                            setDraftTimings((prev) => ({
                              ...prev,
                              greenSec: Number(e.target.value),
                            }))
                          }
                          className="w-full rounded border border-slate-700 bg-[#0A1324] px-2.5 py-1.5 font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-[#EAB308]">Yellow (sec)</label>
                        <input
                          type="number"
                          min={3}
                          max={10}
                          value={draftTimings.yellowSec}
                          onChange={(e) =>
                            setDraftTimings((prev) => ({
                              ...prev,
                              yellowSec: Number(e.target.value),
                            }))
                          }
                          className="w-full rounded border border-slate-700 bg-[#0A1324] px-2.5 py-1.5 font-mono text-white"
                        />
                      </div>
                      <div>
                        <label className="mb-1 block text-[#EF4444]">Red (sec)</label>
                        <input
                          type="number"
                          min={10}
                          max={120}
                          value={draftTimings.redSec}
                          onChange={(e) =>
                            setDraftTimings((prev) => ({
                              ...prev,
                              redSec: Number(e.target.value),
                            }))
                          }
                          className="w-full rounded border border-slate-700 bg-[#0A1324] px-2.5 py-1.5 font-mono text-white"
                        />
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2">
                      <button
                        type="button"
                        onClick={() => setEditingId(null)}
                        className="rounded-md px-3 py-1.5 text-xs text-slate-300 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        disabled={isSaving}
                        onClick={() =>
                          void submitSignalTiming(sig.id, 'manual', draftTimings)
                        }
                        className="rounded-md bg-slate-100 px-3 py-1.5 text-xs font-semibold text-slate-900 hover:bg-white disabled:opacity-50"
                      >
                        Save Manual Timing
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Footer */}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-3.5">
                <button
                  type="button"
                  onClick={() => (isEditing ? setEditingId(null) : openEditor(sig))}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-[#070D19] px-3 py-1.5 text-xs font-medium text-slate-200 hover:border-slate-500"
                >
                  <SlidersHorizontal className="h-3.5 w-3.5" />
                  {isEditing ? 'Close Editor' : 'Manual Timing'}
                </button>

                <button
                  type="button"
                  disabled={isSaving}
                  onClick={() =>
                    void submitSignalTiming(sig.id, 'ai_adaptive', {
                      greenSec: sig.aiRecommendedTimings.greenSec,
                      yellowSec: sig.aiRecommendedTimings.yellowSec,
                      redSec: sig.aiRecommendedTimings.redSec,
                    })
                  }
                  className="inline-flex items-center gap-1.5 rounded-lg bg-[#00E676] px-3.5 py-1.5 text-xs font-semibold text-[#04120B] transition-colors hover:bg-[#1FF58A] disabled:opacity-50"
                >
                  {isSaving ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="h-3.5 w-3.5" />
                  )}
                  Apply AI Optimal Timing
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
