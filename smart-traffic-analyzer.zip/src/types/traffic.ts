export type DensityLevel = 'low' | 'moderate' | 'heavy' | 'severe';
export type SignalPhase = 'green' | 'yellow' | 'red';
export type SignalMode = 'ai_adaptive' | 'manual';
export type ReportTimeframe = 'daily' | 'weekly' | 'monthly';

export interface VehicleBreakdown {
  cars: number;
  bikes: number;
  buses: number;
  trucks: number;
  autoRickshaws: number;
}

export interface RoadCorridor {
  id: string;
  name: string;
  zone: string;
  coordinates: [number, number][];
  lengthKm: number;
  lanes: number;
  vehicles: VehicleBreakdown;
  totalVehicles: number;
  densityScore: number; // 0 - 100
  densityLevel: DensityLevel;
  avgSpeedKmh: number;
  freeFlowSpeedKmh: number;
  incidentNote: string | null;
  lastUpdated: string;
}

export interface TrafficSignal {
  id: string;
  intersectionName: string;
  corridorId: string;
  lat: number;
  lng: number;
  currentPhase: SignalPhase;
  remainingSec: number;
  timings: {
    greenSec: number;
    yellowSec: number;
    redSec: number;
  };
  aiRecommendedTimings: {
    greenSec: number;
    yellowSec: number;
    redSec: number;
    expectedWaitReductionPct: number;
    reason: string;
  };
  mode: SignalMode;
  queueLengthVehicles: number;
  densityLevel: DensityLevel;
}

export interface HourlyTrafficPoint {
  hour: string;
  totalVehicles: number;
  avgSpeedKmh: number;
  congestionPct: number;
}

export interface PeriodReportSeries {
  labels: string[];
  vehicleTotals: number[];
  congestionPct: number[];
  avgSpeedKmh: number[];
  vehicleDistribution: VehicleBreakdown;
  dayComparison: {
    label: string;
    todayVehicles: number;
    previousPeriodVehicles: number;
    congestionDeltaPct: number;
    avgSpeedDeltaKmh: number;
  }[];
}

export interface DetectedBoundingBox {
  label: string;
  category: 'car' | 'bike' | 'bus' | 'truck' | 'auto_rickshaw';
  confidence: number;
  box_2d: [number, number, number, number]; // [ymin, xmin, ymax, xmax] normalized 0-1000
}

export interface VisionAnalysisRecord {
  id: string;
  timestamp: string;
  cameraLabel: string;
  mediaType: 'image' | 'video_frame';
  sourceType: 'live_gemini_vision';
  vehicles: VehicleBreakdown;
  totalVehicles: number;
  densityScore: number;
  densityLevel: DensityLevel;
  estimatedAvgSpeedKmh: number;
  detections: DetectedBoundingBox[];
  summary: string;
  recommendations: string[];
}

export interface TrafficAlert {
  id: string;
  corridorId: string;
  corridorName: string;
  severity: DensityLevel;
  message: string;
  timestamp: string;
}

export interface TrafficSnapshot {
  generatedAt: string;
  dataSource: 'simulated_sensor_grid';
  summary: {
    totalVehiclesDetected: number;
    networkDensityScore: number;
    networkDensityLevel: DensityLevel;
    activeSignalsCount: number;
    congestedRoadsCount: number;
    networkAvgSpeedKmh: number;
    vehicleTotals: VehicleBreakdown;
  };
  corridors: RoadCorridor[];
  signals: TrafficSignal[];
  alerts: TrafficAlert[];
  hourlySeries: HourlyTrafficPoint[];
  reports: Record<ReportTimeframe, PeriodReportSeries>;
  recentVisionAnalyses: VisionAnalysisRecord[];
}

export interface PredictionForecastItem {
  corridorId: string;
  corridorName: string;
  currentDensityLevel: DensityLevel;
  forecast30mLevel: DensityLevel;
  forecast30mSpeedKmh: number;
  forecast60mLevel: DensityLevel;
  forecast60mSpeedKmh: number;
  congestionProbabilityPct: number;
  hotspotWarning: string;
}

export interface RecommendedRoute {
  routeName: string;
  isFastest: boolean;
  corridorNames: string[];
  corridorIds: string[];
  distanceKm: number;
  estimatedTimeMin: number;
  timeSavedMin: number;
  densityLevel: DensityLevel;
  rationale: string;
}

export interface TrafficPredictionResponse {
  generatedAt: string;
  sourceType: 'live_gemini_prediction';
  originName: string;
  destinationName: string;
  networkOutlookSummary: string;
  forecasts: PredictionForecastItem[];
  recommendedRoutes: RecommendedRoute[];
  signalAdvisories: string[];
}
