import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import {
  buildTrafficSnapshot,
  classifyDensity,
  getSignalSeedIds,
  recordVisionAnalysis,
  updateSignalOverride,
} from './server/trafficEngine.ts';
import type {
  DetectedBoundingBox,
  ReportTimeframe,
  SignalMode,
  TrafficPredictionResponse,
  VisionAnalysisRecord,
} from './src/types/traffic.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = 3000;
const ALLOWED_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_BASE64_BYTES = 8 * 1024 * 1024;

function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY is not configured in the server environment.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function escapeCsvField(value: string | number): string {
  const str = String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '12mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  app.get('/api/traffic/snapshot', (_req, res) => {
    const snapshot = buildTrafficSnapshot();
    res.json(snapshot);
  });

  app.post('/api/signals/:id/optimize', (req, res) => {
    const { id } = req.params;
    const validIds = getSignalSeedIds();
    if (!validIds.includes(id)) {
      res.status(404).json({ error: 'Traffic signal controller not found.' });
      return;
    }

    const { mode, greenSec, yellowSec, redSec } = req.body ?? {};
    const validMode: SignalMode = mode === 'manual' ? 'manual' : 'ai_adaptive';

    if (
      typeof greenSec !== 'number' ||
      typeof yellowSec !== 'number' ||
      typeof redSec !== 'number' ||
      Number.isNaN(greenSec) ||
      Number.isNaN(yellowSec) ||
      Number.isNaN(redSec)
    ) {
      res.status(400).json({ error: 'Valid numeric greenSec, yellowSec, and redSec values are required.' });
      return;
    }

    updateSignalOverride(id, {
      mode: validMode,
      greenSec,
      yellowSec,
      redSec,
    });

    const snapshot = buildTrafficSnapshot();
    res.json(snapshot);
  });

  app.post('/api/analyze-media', async (req, res) => {
    try {
      const { imageBase64, mimeType, cameraLabel, mediaType } = req.body ?? {};

      if (typeof imageBase64 !== 'string' || imageBase64.length < 32) {
        res.status(400).json({ error: 'A valid base64-encoded image or video frame is required.' });
        return;
      }

      const normalizedMime = typeof mimeType === 'string' ? mimeType.toLowerCase() : 'image/jpeg';
      if (!ALLOWED_MIME_TYPES.has(normalizedMime)) {
        res.status(400).json({ error: 'Unsupported media format. Upload JPEG, PNG, or WebP.' });
        return;
      }

      const cleanBase64 = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
      const estimatedBytes = Math.ceil((cleanBase64.length * 3) / 4);
      if (estimatedBytes > MAX_BASE64_BYTES) {
        res.status(413).json({ error: 'Uploaded frame exceeds the 8MB analysis limit.' });
        return;
      }

      const ai = createGeminiClient();
      const safeLabel =
        typeof cameraLabel === 'string' && cameraLabel.trim().length > 0
          ? cameraLabel.trim().slice(0, 80)
          : 'Uploaded Traffic Feed';
      const safeMediaType = mediaType === 'video_frame' ? 'video_frame' : 'image';

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: normalizedMime,
                data: cleanBase64,
              },
            },
            {
              text:
                'Analyze this traffic scene as an intelligent urban traffic computer vision system. ' +
                'Count all visible vehicles accurately across 5 categories: cars (include sedans, SUVs, vans, taxis), ' +
                'bikes (motorcycles, scooters, bicycles), buses, trucks (freight trucks, lorries, delivery box trucks), ' +
                'and autoRickshaws (three-wheeled auto-rickshaws/tuk-tuks). ' +
                'Estimate overall traffic density score (0 to 100) and average traffic flow speed in km/h. ' +
                'Return up to 18 prominent vehicle bounding boxes using normalized [ymin, xmin, ymax, xmax] coordinates from 0 to 1000. ' +
                'Provide a concise 1-2 sentence traffic scene summary and 3 actionable traffic management recommendations.',
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              cars: { type: Type.INTEGER },
              bikes: { type: Type.INTEGER },
              buses: { type: Type.INTEGER },
              trucks: { type: Type.INTEGER },
              autoRickshaws: { type: Type.INTEGER },
              densityScore: { type: Type.INTEGER },
              estimatedAvgSpeedKmh: { type: Type.INTEGER },
              detections: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    label: { type: Type.STRING },
                    category: {
                      type: Type.STRING,
                      description: 'Must be one of: car, bike, bus, truck, auto_rickshaw',
                    },
                    confidence: { type: Type.NUMBER },
                    box_2d: {
                      type: Type.ARRAY,
                      items: { type: Type.INTEGER },
                      description: 'Normalized [ymin, xmin, ymax, xmax] integers between 0 and 1000',
                    },
                  },
                  required: ['label', 'category', 'confidence', 'box_2d'],
                },
              },
              summary: { type: Type.STRING },
              recommendations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              'cars',
              'bikes',
              'buses',
              'trucks',
              'autoRickshaws',
              'densityScore',
              'estimatedAvgSpeedKmh',
              'detections',
              'summary',
              'recommendations',
            ],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({ error: 'Gemini AI returned an empty detection payload.' });
        return;
      }

      const parsed = JSON.parse(rawText) as {
        cars: number;
        bikes: number;
        buses: number;
        trucks: number;
        autoRickshaws: number;
        densityScore: number;
        estimatedAvgSpeedKmh: number;
        detections: DetectedBoundingBox[];
        summary: string;
        recommendations: string[];
      };

      const cars = Math.max(0, Math.round(parsed.cars ?? 0));
      const bikes = Math.max(0, Math.round(parsed.bikes ?? 0));
      const buses = Math.max(0, Math.round(parsed.buses ?? 0));
      const trucks = Math.max(0, Math.round(parsed.trucks ?? 0));
      const autoRickshaws = Math.max(0, Math.round(parsed.autoRickshaws ?? 0));
      const totalVehicles = cars + bikes + buses + trucks + autoRickshaws;
      const densityScore = Math.max(0, Math.min(100, Math.round(parsed.densityScore ?? 0)));

      const validCategories = new Set(['car', 'bike', 'bus', 'truck', 'auto_rickshaw']);
      const detections: DetectedBoundingBox[] = (Array.isArray(parsed.detections) ? parsed.detections : [])
        .filter((d) => Array.isArray(d.box_2d) && d.box_2d.length === 4)
        .slice(0, 20)
        .map((d) => {
          const cat = validCategories.has(d.category) ? d.category : 'car';
          return {
            label: String(d.label || cat).slice(0, 32),
            category: cat,
            confidence: Math.max(0.5, Math.min(0.99, Number(d.confidence) || 0.88)),
            box_2d: [
              Math.max(0, Math.min(1000, Math.round(d.box_2d[0]))),
              Math.max(0, Math.min(1000, Math.round(d.box_2d[1]))),
              Math.max(0, Math.min(1000, Math.round(d.box_2d[2]))),
              Math.max(0, Math.min(1000, Math.round(d.box_2d[3]))),
            ],
          };
        });

      const record: VisionAnalysisRecord = {
        id: `vis-${Date.now()}`,
        timestamp: new Date().toISOString(),
        cameraLabel: safeLabel,
        mediaType: safeMediaType,
        sourceType: 'live_gemini_vision',
        vehicles: { cars, bikes, buses, trucks, autoRickshaws },
        totalVehicles,
        densityScore,
        densityLevel: classifyDensity(densityScore),
        estimatedAvgSpeedKmh: Math.max(0, Math.min(120, Math.round(parsed.estimatedAvgSpeedKmh ?? 25))),
        detections,
        summary: String(parsed.summary || 'Vehicle detection completed.').slice(0, 320),
        recommendations: (Array.isArray(parsed.recommendations) ? parsed.recommendations : [])
          .slice(0, 4)
          .map((r) => String(r).slice(0, 180)),
      };

      recordVisionAnalysis(record);
      res.json(record);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to analyze uploaded traffic media.';
      res.status(500).json({ error: message });
    }
  });

  app.post('/api/predict-traffic', async (req, res) => {
    try {
      const { originId, destinationId } = req.body ?? {};
      const snapshot = buildTrafficSnapshot();

      const originCorridor =
        snapshot.corridors.find((c) => c.id === originId) ?? snapshot.corridors[0];
      const destCorridor =
        snapshot.corridors.find((c) => c.id === destinationId) ?? snapshot.corridors[1];

      const ai = createGeminiClient();

      const corridorDigest = snapshot.corridors.map((c) => ({
        id: c.id,
        name: c.name,
        zone: c.zone,
        lengthKm: c.lengthKm,
        densityScore: c.densityScore,
        densityLevel: c.densityLevel,
        avgSpeedKmh: c.avgSpeedKmh,
        totalVehicles: c.totalVehicles,
        incidentNote: c.incidentNote,
      }));

      const prompt = `You are a Smart City Traffic Forecasting & Routing AI.
Current simulated urban corridor state (timestamp ${snapshot.generatedAt}):
${JSON.stringify(corridorDigest)}

Recent hourly pattern:
${JSON.stringify(snapshot.hourlySeries.slice(6, 15))}

Task:
1. Forecast traffic conditions for the next 30 minutes and 60 minutes across the top 6 critical corridors (include "${originCorridor.name}" and "${destCorridor.name}").
2. Recommend 3 candidate routes between origin "${originCorridor.name}" (${originCorridor.zone}) and destination "${destCorridor.name}" (${destCorridor.zone}), marking the fastest route with isFastest: true and estimating realistic travel times, distances, time saved vs congested route, and corridor IDs from the provided list.
3. Provide 3 concise signal timing or corridor diversion advisories.`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              networkOutlookSummary: { type: Type.STRING },
              forecasts: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    corridorId: { type: Type.STRING },
                    corridorName: { type: Type.STRING },
                    currentDensityLevel: { type: Type.STRING },
                    forecast30mLevel: { type: Type.STRING },
                    forecast30mSpeedKmh: { type: Type.INTEGER },
                    forecast60mLevel: { type: Type.STRING },
                    forecast60mSpeedKmh: { type: Type.INTEGER },
                    congestionProbabilityPct: { type: Type.INTEGER },
                    hotspotWarning: { type: Type.STRING },
                  },
                  required: [
                    'corridorId',
                    'corridorName',
                    'currentDensityLevel',
                    'forecast30mLevel',
                    'forecast30mSpeedKmh',
                    'forecast60mLevel',
                    'forecast60mSpeedKmh',
                    'congestionProbabilityPct',
                    'hotspotWarning',
                  ],
                },
              },
              recommendedRoutes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    routeName: { type: Type.STRING },
                    isFastest: { type: Type.BOOLEAN },
                    corridorNames: { type: Type.ARRAY, items: { type: Type.STRING } },
                    corridorIds: { type: Type.ARRAY, items: { type: Type.STRING } },
                    distanceKm: { type: Type.NUMBER },
                    estimatedTimeMin: { type: Type.INTEGER },
                    timeSavedMin: { type: Type.INTEGER },
                    densityLevel: { type: Type.STRING },
                    rationale: { type: Type.STRING },
                  },
                  required: [
                    'routeName',
                    'isFastest',
                    'corridorNames',
                    'corridorIds',
                    'distanceKm',
                    'estimatedTimeMin',
                    'timeSavedMin',
                    'densityLevel',
                    'rationale',
                  ],
                },
              },
              signalAdvisories: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['networkOutlookSummary', 'forecasts', 'recommendedRoutes', 'signalAdvisories'],
          },
        },
      });

      const rawText = (response.text ?? '').trim();
      if (!rawText) {
        res.status(502).json({ error: 'Gemini AI returned an empty prediction response.' });
        return;
      }

      const parsed = JSON.parse(rawText) as Omit<
        TrafficPredictionResponse,
        'generatedAt' | 'sourceType' | 'originName' | 'destinationName'
      >;

      const validLevels = new Set(['low', 'moderate', 'heavy', 'severe']);
      const normalizeLevel = (lvl: string) =>
        (validLevels.has(lvl) ? lvl : 'moderate') as 'low' | 'moderate' | 'heavy' | 'severe';

      const payload: TrafficPredictionResponse = {
        generatedAt: new Date().toISOString(),
        sourceType: 'live_gemini_prediction',
        originName: originCorridor.name,
        destinationName: destCorridor.name,
        networkOutlookSummary: parsed.networkOutlookSummary,
        forecasts: (parsed.forecasts ?? []).slice(0, 6).map((f) => ({
          ...f,
          currentDensityLevel: normalizeLevel(f.currentDensityLevel),
          forecast30mLevel: normalizeLevel(f.forecast30mLevel),
          forecast60mLevel: normalizeLevel(f.forecast60mLevel),
        })),
        recommendedRoutes: (parsed.recommendedRoutes ?? []).slice(0, 3).map((r) => ({
          ...r,
          densityLevel: normalizeLevel(r.densityLevel),
        })),
        signalAdvisories: (parsed.signalAdvisories ?? []).slice(0, 4),
      };

      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Failed to generate AI traffic prediction.';
      res.status(500).json({ error: message });
    }
  });

  app.get('/api/reports/download', (req, res) => {
    const timeframeParam = String(req.query.timeframe || 'daily').toLowerCase();
    const formatParam = String(req.query.format || 'csv').toLowerCase();
    const timeframe: ReportTimeframe =
      timeframeParam === 'weekly' || timeframeParam === 'monthly' ? timeframeParam : 'daily';

    const snapshot = buildTrafficSnapshot();
    const report = snapshot.reports[timeframe];

    if (formatParam === 'json') {
      res.setHeader('Content-Type', 'application/json');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="smart-traffic-report-${timeframe}.json"`
      );
      res.send(
        JSON.stringify(
          {
            generatedAt: snapshot.generatedAt,
            dataSource: snapshot.dataSource,
            timeframe,
            summary: snapshot.summary,
            report,
            corridors: snapshot.corridors,
          },
          null,
          2
        )
      );
      return;
    }

    const lines: string[] = [
      'Section,Label,Vehicle Count,Congestion %,Avg Speed (km/h),Density Level,Notes',
    ];

    report.labels.forEach((label, idx) => {
      lines.push(
        [
          escapeCsvField(`${timeframe.toUpperCase()} SERIES`),
          escapeCsvField(label),
          escapeCsvField(report.vehicleTotals[idx] ?? 0),
          escapeCsvField(report.congestionPct[idx] ?? 0),
          escapeCsvField(report.avgSpeedKmh[idx] ?? 0),
          escapeCsvField(classifyDensity(report.congestionPct[idx] ?? 0)),
          escapeCsvField('Simulated sensor grid'),
        ].join(',')
      );
    });

    snapshot.corridors.forEach((c) => {
      lines.push(
        [
          escapeCsvField('CORRIDOR SNAPSHOT'),
          escapeCsvField(c.name),
          escapeCsvField(c.totalVehicles),
          escapeCsvField(c.densityScore),
          escapeCsvField(c.avgSpeedKmh),
          escapeCsvField(c.densityLevel),
          escapeCsvField(c.incidentNote ?? 'Normal flow'),
        ].join(',')
      );
    });

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="smart-traffic-report-${timeframe}.csv"`
    );
    res.send(lines.join('\n'));
  });

  app.get('/api/project/download-zip', (_req, res) => {
    const zipPath = path.resolve(__dirname, 'downloads', 'smart-traffic-analyzer.zip');
    if (!fs.existsSync(zipPath)) {
      res.status(404).json({ error: 'Project archive is not packaged yet.' });
      return;
    }
    res.download(zipPath, 'smart-traffic-analyzer.zip');
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Traffic Analyzer server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
