import fs from 'fs';
import path from 'path';
import type {
  DensityLevel,
  PeriodReportSeries,
  ReportTimeframe,
  RoadCorridor,
  SignalMode,
  SignalPhase,
  TrafficAlert,
  TrafficSignal,
  TrafficSnapshot,
  VehicleBreakdown,
  VisionAnalysisRecord,
} from '../src/types/traffic.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const STORE_PATH = path.join(DATA_DIR, 'traffic_store.json');

interface PersistedState {
  signalOverrides: Record<
    string,
    {
      mode: SignalMode;
      greenSec: number;
      yellowSec: number;
      redSec: number;
    }
  >;
  visionAnalyses: VisionAnalysisRecord[];
}

interface CorridorSeed {
  id: string;
  name: string;
  zone: string;
  coordinates: [number, number][];
  lengthKm: number;
  lanes: number;
  freeFlowSpeedKmh: number;
  baseVehicles: VehicleBreakdown;
  incidentNote: string | null;
  phaseOffset: number;
}

const CORRIDOR_SEEDS: CorridorSeed[] = [
  {
    id: 'cor-mg-road',
    name: 'MG Road Central Spine',
    zone: 'Central Business District',
    coordinates: [
      [12.9758, 77.5995],
      [12.9752, 77.6062],
      [12.9746, 77.6138],
      [12.9739, 77.6202],
    ],
    lengthKm: 3.4,
    lanes: 6,
    freeFlowSpeedKmh: 55,
    baseVehicles: { cars: 245, bikes: 185, buses: 28, trucks: 14, autoRickshaws: 112 },
    incidentNote: 'High bus-bay dwell volume near Trinity Junction',
    phaseOffset: 0.2,
  },
  {
    id: 'cor-outer-ring',
    name: 'Outer Ring Express Corridor',
    zone: 'East Tech Belt',
    coordinates: [
      [12.9895, 77.6415],
      [12.9788, 77.6532],
      [12.9665, 77.6615],
      [12.9532, 77.6672],
    ],
    lengthKm: 5.8,
    lanes: 8,
    freeFlowSpeedKmh: 70,
    baseVehicles: { cars: 410, bikes: 260, buses: 44, trucks: 58, autoRickshaws: 94 },
    incidentNote: 'Severe merge bottleneck at Marathahalli Ramp',
    phaseOffset: 1.1,
  },
  {
    id: 'cor-silk-board',
    name: 'Silk Board Interchange',
    zone: 'South Arterial',
    coordinates: [
      [12.9318, 77.6112],
      [12.9248, 77.6185],
      [12.9175, 77.6238],
      [12.9102, 77.6292],
    ],
    lengthKm: 4.1,
    lanes: 6,
    freeFlowSpeedKmh: 60,
    baseVehicles: { cars: 365, bikes: 295, buses: 52, trucks: 41, autoRickshaws: 148 },
    incidentNote: 'Peak queue spillback across southern flyover loop',
    phaseOffset: 1.9,
  },
  {
    id: 'cor-indiranagar-100ft',
    name: '100 Feet Road Commercial',
    zone: 'East Metro',
    coordinates: [
      [12.9832, 77.6408],
      [12.9742, 77.6411],
      [12.9658, 77.6409],
    ],
    lengthKm: 2.3,
    lanes: 4,
    freeFlowSpeedKmh: 45,
    baseVehicles: { cars: 162, bikes: 144, buses: 14, trucks: 9, autoRickshaws: 86 },
    incidentNote: null,
    phaseOffset: 2.6,
  },
  {
    id: 'cor-cubbon-ring',
    name: 'Kasturba Park Boulevard',
    zone: 'Civic Core',
    coordinates: [
      [12.9812, 77.5902],
      [12.9762, 77.5931],
      [12.9708, 77.5964],
      [12.9654, 77.5998],
    ],
    lengthKm: 2.1,
    lanes: 4,
    freeFlowSpeedKmh: 50,
    baseVehicles: { cars: 96, bikes: 72, buses: 12, trucks: 4, autoRickshaws: 38 },
    incidentNote: null,
    phaseOffset: 3.4,
  },
  {
    id: 'cor-hosur-elevated',
    name: 'Hosur Elevated Tollway',
    zone: 'South Industrial',
    coordinates: [
      [12.9482, 77.6062],
      [12.9368, 77.6145],
      [12.9248, 77.6185],
    ],
    lengthKm: 3.9,
    lanes: 6,
    freeFlowSpeedKmh: 65,
    baseVehicles: { cars: 215, bikes: 132, buses: 29, trucks: 46, autoRickshaws: 64 },
    incidentNote: 'Freight convoy lane compression northbound',
    phaseOffset: 4.0,
  },
  {
    id: 'cor-mekhri-north',
    name: 'Bellary Airport Arterial',
    zone: 'North Corridor',
    coordinates: [
      [13.0124, 77.5835],
      [13.0012, 77.5868],
      [12.9905, 77.5892],
      [12.9812, 77.5902],
    ],
    lengthKm: 4.5,
    lanes: 6,
    freeFlowSpeedKmh: 70,
    baseVehicles: { cars: 188, bikes: 94, buses: 22, trucks: 24, autoRickshaws: 41 },
    incidentNote: null,
    phaseOffset: 4.8,
  },
  {
    id: 'cor-koramangala-inner',
    name: 'Koramangala 80ft Link',
    zone: 'Southeast Grid',
    coordinates: [
      [12.9658, 77.6409],
      [12.9495, 77.6328],
      [12.9348, 77.6264],
      [12.9248, 77.6185],
    ],
    lengthKm: 4.8,
    lanes: 4,
    freeFlowSpeedKmh: 50,
    baseVehicles: { cars: 145, bikes: 122, buses: 18, trucks: 11, autoRickshaws: 74 },
    incidentNote: null,
    phaseOffset: 5.5,
  },
  {
    id: 'cor-mysore-west',
    name: 'Mysore Road Freight Link',
    zone: 'West Gateway',
    coordinates: [
      [12.9654, 77.5998],
      [12.9598, 77.5842],
      [12.9542, 77.5685],
    ],
    lengthKm: 3.7,
    lanes: 6,
    freeFlowSpeedKmh: 60,
    baseVehicles: { cars: 192, bikes: 158, buses: 26, trucks: 54, autoRickshaws: 82 },
    incidentNote: 'Heavy commercial truck inflow at Satellite Terminal',
    phaseOffset: 2.2,
  },
  {
    id: 'cor-richmond-bypass',
    name: 'Richmond Circle Bypass',
    zone: 'Central South',
    coordinates: [
      [12.9654, 77.5998],
      [12.9585, 77.6032],
      [12.9482, 77.6062],
    ],
    lengthKm: 2.2,
    lanes: 4,
    freeFlowSpeedKmh: 45,
    baseVehicles: { cars: 84, bikes: 65, buses: 10, trucks: 6, autoRickshaws: 35 },
    incidentNote: null,
    phaseOffset: 0.9,
  },
];

interface SignalSeed {
  id: string;
  intersectionName: string;
  corridorId: string;
  lat: number;
  lng: number;
  baseGreenSec: number;
  baseYellowSec: number;
  baseRedSec: number;
  offsetSec: number;
}

const SIGNAL_SEEDS: SignalSeed[] = [
  {
    id: 'sig-trinity',
    intersectionName: 'Trinity Circle Junction',
    corridorId: 'cor-mg-road',
    lat: 12.9746,
    lng: 77.6138,
    baseGreenSec: 42,
    baseYellowSec: 5,
    baseRedSec: 48,
    offsetSec: 12,
  },
  {
    id: 'sig-marathahalli',
    intersectionName: 'Marathahalli Ring Signal',
    corridorId: 'cor-outer-ring',
    lat: 12.9665,
    lng: 77.6615,
    baseGreenSec: 36,
    baseYellowSec: 5,
    baseRedSec: 54,
    offsetSec: 34,
  },
  {
    id: 'sig-silkboard',
    intersectionName: 'Silk Board Central Mast',
    corridorId: 'cor-silk-board',
    lat: 12.9175,
    lng: 77.6238,
    baseGreenSec: 34,
    baseYellowSec: 5,
    baseRedSec: 58,
    offsetSec: 51,
  },
  {
    id: 'sig-domlur',
    intersectionName: 'Domlur 100ft Crossing',
    corridorId: 'cor-indiranagar-100ft',
    lat: 12.9658,
    lng: 77.6409,
    baseGreenSec: 45,
    baseYellowSec: 4,
    baseRedSec: 40,
    offsetSec: 21,
  },
  {
    id: 'sig-queens',
    intersectionName: 'Queens Park Rotary',
    corridorId: 'cor-cubbon-ring',
    lat: 12.9762,
    lng: 77.5931,
    baseGreenSec: 48,
    baseYellowSec: 4,
    baseRedSec: 32,
    offsetSec: 6,
  },
  {
    id: 'sig-madivala',
    intersectionName: 'Madivala Toll Approach',
    corridorId: 'cor-hosur-elevated',
    lat: 12.9248,
    lng: 77.6185,
    baseGreenSec: 40,
    baseYellowSec: 5,
    baseRedSec: 46,
    offsetSec: 44,
  },
  {
    id: 'sig-mekhri',
    intersectionName: 'Mekhri Circle Underpass',
    corridorId: 'cor-mekhri-north',
    lat: 12.9905,
    lng: 77.5892,
    baseGreenSec: 44,
    baseYellowSec: 4,
    baseRedSec: 38,
    offsetSec: 18,
  },
  {
    id: 'sig-richmond',
    intersectionName: 'Richmond Flyover Gate',
    corridorId: 'cor-richmond-bypass',
    lat: 12.9585,
    lng: 77.6032,
    baseGreenSec: 46,
    baseYellowSec: 4,
    baseRedSec: 34,
    offsetSec: 29,
  },
];

function ensureStore(): PersistedState {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(STORE_PATH)) {
    const initial: PersistedState = {
      signalOverrides: {},
      visionAnalyses: [],
    };
    fs.writeFileSync(STORE_PATH, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
  try {
    const raw = fs.readFileSync(STORE_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as PersistedState;
    return {
      signalOverrides: parsed.signalOverrides ?? {},
      visionAnalyses: Array.isArray(parsed.visionAnalyses) ? parsed.visionAnalyses : [],
    };
  } catch {
    return { signalOverrides: {}, visionAnalyses: [] };
  }
}

function saveStore(state: PersistedState): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  fs.writeFileSync(STORE_PATH, JSON.stringify(state, null, 2), 'utf-8');
}

export function classifyDensity(score: number): DensityLevel {
  if (score >= 80) return 'severe';
  if (score >= 60) return 'heavy';
  if (score >= 38) return 'moderate';
  return 'low';
}

function sumVehicles(v: VehicleBreakdown): number {
  return v.cars + v.bikes + v.buses + v.trucks + v.autoRickshaws;
}

export function updateSignalOverride(
  signalId: string,
  payload: { mode: SignalMode; greenSec: number; yellowSec: number; redSec: number }
): void {
  const state = ensureStore();
  state.signalOverrides[signalId] = {
    mode: payload.mode,
    greenSec: Math.max(10, Math.min(120, Math.round(payload.greenSec))),
    yellowSec: Math.max(3, Math.min(10, Math.round(payload.yellowSec))),
    redSec: Math.max(10, Math.min(120, Math.round(payload.redSec))),
  };
  saveStore(state);
}

export function recordVisionAnalysis(record: VisionAnalysisRecord): void {
  const state = ensureStore();
  state.visionAnalyses = [record, ...state.visionAnalyses].slice(0, 15);
  saveStore(state);
}

export function getSignalSeedIds(): string[] {
  return SIGNAL_SEEDS.map((s) => s.id);
}

export function buildTrafficSnapshot(): TrafficSnapshot {
  const store = ensureStore();
  const now = new Date();
  const t = now.getTime() / 1000;

  const corridors: RoadCorridor[] = CORRIDOR_SEEDS.map((seed) => {
    const wave = Math.sin(t / 14 + seed.phaseOffset);
    const micro = Math.cos(t / 6 + seed.phaseOffset * 2);
    const multiplier = 1 + wave * 0.11 + micro * 0.04;

    const vehicles: VehicleBreakdown = {
      cars: Math.max(10, Math.round(seed.baseVehicles.cars * multiplier)),
      bikes: Math.max(8, Math.round(seed.baseVehicles.bikes * (multiplier + 0.03))),
      buses: Math.max(2, Math.round(seed.baseVehicles.buses * (1 + wave * 0.07))),
      trucks: Math.max(1, Math.round(seed.baseVehicles.trucks * (1 + micro * 0.08))),
      autoRickshaws: Math.max(4, Math.round(seed.baseVehicles.autoRickshaws * multiplier)),
    };

    const totalVehicles = sumVehicles(vehicles);
    const capacityFactor = seed.lanes * seed.lengthKm * 36;
    const rawDensity = Math.min(98, Math.max(14, Math.round((totalVehicles / capacityFactor) * 100)));
    const densityLevel = classifyDensity(rawDensity);

    const speedFactor = Math.max(0.22, 1 - (rawDensity / 112));
    const avgSpeedKmh = Math.max(11, Math.round(seed.freeFlowSpeedKmh * speedFactor));

    return {
      id: seed.id,
      name: seed.name,
      zone: seed.zone,
      coordinates: seed.coordinates,
      lengthKm: seed.lengthKm,
      lanes: seed.lanes,
      vehicles,
      totalVehicles,
      densityScore: rawDensity,
      densityLevel,
      avgSpeedKmh,
      freeFlowSpeedKmh: seed.freeFlowSpeedKmh,
      incidentNote: rawDensity >= 65 ? seed.incidentNote : null,
      lastUpdated: now.toISOString(),
    };
  });

  const corridorMap = new Map(corridors.map((c) => [c.id, c]));

  const signals: TrafficSignal[] = SIGNAL_SEEDS.map((seed) => {
    const corridor = corridorMap.get(seed.corridorId)!;
    const override = store.signalOverrides[seed.id];

    const greenSec = override ? override.greenSec : seed.baseGreenSec;
    const yellowSec = override ? override.yellowSec : seed.baseYellowSec;
    const redSec = override ? override.redSec : seed.baseRedSec;
    const mode: SignalMode = override ? override.mode : 'ai_adaptive';

    const cycleSec = greenSec + yellowSec + redSec;
    const elapsedInCycle = Math.floor((t + seed.offsetSec) % cycleSec);

    let currentPhase: SignalPhase = 'green';
    let remainingSec = 0;

    if (elapsedInCycle < greenSec) {
      currentPhase = 'green';
      remainingSec = greenSec - elapsedInCycle;
    } else if (elapsedInCycle < greenSec + yellowSec) {
      currentPhase = 'yellow';
      remainingSec = greenSec + yellowSec - elapsedInCycle;
    } else {
      currentPhase = 'red';
      remainingSec = cycleSec - elapsedInCycle;
    }

    const densityBonus = corridor.densityScore >= 75 ? 16 : corridor.densityScore >= 55 ? 8 : -6;
    const recommendedGreen = Math.max(24, Math.min(72, seed.baseGreenSec + densityBonus));
    const recommendedYellow = 4;
    const recommendedRed = Math.max(22, Math.min(64, seed.baseRedSec - Math.round(densityBonus * 0.6)));
    const expectedWaitReductionPct =
      corridor.densityScore >= 75 ? 24 : corridor.densityScore >= 55 ? 16 : 9;

    const queueLengthVehicles = Math.max(
      4,
      Math.round((corridor.densityScore / 100) * (currentPhase === 'red' ? 42 : 18))
    );

    return {
      id: seed.id,
      intersectionName: seed.intersectionName,
      corridorId: seed.corridorId,
      lat: seed.lat,
      lng: seed.lng,
      currentPhase,
      remainingSec,
      timings: { greenSec, yellowSec, redSec },
      aiRecommendedTimings: {
        greenSec: recommendedGreen,
        yellowSec: recommendedYellow,
        redSec: recommendedRed,
        expectedWaitReductionPct,
        reason:
          corridor.densityScore >= 65
            ? `Extend green phase by ${Math.max(4, recommendedGreen - greenSec)}s to clear ${corridor.name} queue spillback.`
            : `Balanced flow; trim red cycle to maintain green-wave progression.`,
      },
      mode,
      queueLengthVehicles,
      densityLevel: corridor.densityLevel,
    };
  });

  const vehicleTotals: VehicleBreakdown = corridors.reduce(
    (acc, c) => ({
      cars: acc.cars + c.vehicles.cars,
      bikes: acc.bikes + c.vehicles.bikes,
      buses: acc.buses + c.vehicles.buses,
      trucks: acc.trucks + c.vehicles.trucks,
      autoRickshaws: acc.autoRickshaws + c.vehicles.autoRickshaws,
    }),
    { cars: 0, bikes: 0, buses: 0, trucks: 0, autoRickshaws: 0 }
  );

  const totalVehiclesDetected = sumVehicles(vehicleTotals);
  const networkDensityScore = Math.round(
    corridors.reduce((acc, c) => acc + c.densityScore, 0) / corridors.length
  );
  const networkAvgSpeedKmh = Math.round(
    corridors.reduce((acc, c) => acc + c.avgSpeedKmh, 0) / corridors.length
  );
  const congestedRoadsCount = corridors.filter(
    (c) => c.densityLevel === 'heavy' || c.densityLevel === 'severe'
  ).length;

  const alerts: TrafficAlert[] = corridors
    .filter((c) => c.densityLevel === 'severe' || c.densityLevel === 'heavy')
    .sort((a, b) => b.densityScore - a.densityScore)
    .map((c) => ({
      id: `alert-${c.id}`,
      corridorId: c.id,
      corridorName: c.name,
      severity: c.densityLevel,
      message:
        c.incidentNote ??
        `Elevated density (${c.densityScore}%) · avg speed ${c.avgSpeedKmh} km/h across ${c.lanes} lanes`,
      timestamp: now.toISOString(),
    }));

  const hourlySeries = [
    { hour: '06:00', totalVehicles: 1420, avgSpeedKmh: 54, congestionPct: 24 },
    { hour: '07:00', totalVehicles: 2290, avgSpeedKmh: 46, congestionPct: 41 },
    { hour: '08:00', totalVehicles: 3840, avgSpeedKmh: 31, congestionPct: 72 },
    { hour: '09:00', totalVehicles: 4680, avgSpeedKmh: 22, congestionPct: 86 },
    { hour: '10:00', totalVehicles: 4210, avgSpeedKmh: 27, congestionPct: 78 },
    { hour: '11:00', totalVehicles: 3390, avgSpeedKmh: 36, congestionPct: 58 },
    { hour: '12:00', totalVehicles: 3120, avgSpeedKmh: 38, congestionPct: 52 },
    { hour: '13:00', totalVehicles: 3250, avgSpeedKmh: 37, congestionPct: 54 },
    { hour: '14:00', totalVehicles: 3040, avgSpeedKmh: 40, congestionPct: 49 },
    { hour: '15:00', totalVehicles: 3360, avgSpeedKmh: 36, congestionPct: 56 },
    { hour: '16:00', totalVehicles: 3980, avgSpeedKmh: 29, congestionPct: 69 },
    { hour: '17:00', totalVehicles: 4890, avgSpeedKmh: 20, congestionPct: 89 },
    { hour: '18:00', totalVehicles: 5240, avgSpeedKmh: 18, congestionPct: 93 },
    { hour: '19:00', totalVehicles: 4720, avgSpeedKmh: 23, congestionPct: 84 },
    { hour: '20:00', totalVehicles: 3640, avgSpeedKmh: 34, congestionPct: 61 },
    { hour: '21:00', totalVehicles: 2510, avgSpeedKmh: 44, congestionPct: 39 },
    { hour: '22:00', totalVehicles: 1680, avgSpeedKmh: 52, congestionPct: 26 },
  ];

  const reports: Record<ReportTimeframe, PeriodReportSeries> = {
    daily: {
      labels: ['06:00', '09:00', '12:00', '15:00', '18:00', '21:00'],
      vehicleTotals: [1420, 4680, 3120, 3360, 5240, 2510],
      congestionPct: [24, 86, 52, 56, 93, 39],
      avgSpeedKmh: [54, 22, 38, 36, 18, 44],
      vehicleDistribution: vehicleTotals,
      dayComparison: [
        {
          label: 'Morning Peak (08:00–10:00)',
          todayVehicles: 12730,
          previousPeriodVehicles: 11940,
          congestionDeltaPct: 4.8,
          avgSpeedDeltaKmh: -2.4,
        },
        {
          label: 'Midday Window (11:00–15:00)',
          todayVehicles: 13060,
          previousPeriodVehicles: 13410,
          congestionDeltaPct: -2.6,
          avgSpeedDeltaKmh: 1.9,
        },
        {
          label: 'Evening Peak (17:00–20:00)',
          todayVehicles: 14850,
          previousPeriodVehicles: 13980,
          congestionDeltaPct: 6.2,
          avgSpeedDeltaKmh: -3.1,
        },
      ],
    },
    weekly: {
      labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      vehicleTotals: [58420, 61250, 62910, 60840, 66780, 49320, 38140],
      congestionPct: [64, 68, 71, 67, 79, 51, 34],
      avgSpeedKmh: [32, 30, 28, 31, 24, 41, 49],
      vehicleDistribution: {
        cars: 171240,
        bikes: 124680,
        buses: 22190,
        trucks: 24310,
        autoRickshaws: 55240,
      },
      dayComparison: [
        {
          label: 'Weekday Average (Mon–Fri)',
          todayVehicles: 62040,
          previousPeriodVehicles: 59820,
          congestionDeltaPct: 3.7,
          avgSpeedDeltaKmh: -1.8,
        },
        {
          label: 'Friday Peak Corridor',
          todayVehicles: 66780,
          previousPeriodVehicles: 63400,
          congestionDeltaPct: 5.3,
          avgSpeedDeltaKmh: -2.9,
        },
        {
          label: 'Weekend Average (Sat–Sun)',
          todayVehicles: 43730,
          previousPeriodVehicles: 44890,
          congestionDeltaPct: -2.6,
          avgSpeedDeltaKmh: 2.3,
        },
      ],
    },
    monthly: {
      labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
      vehicleTotals: [389400, 402150, 415800, 397660],
      congestionPct: [61, 65, 69, 63],
      avgSpeedKmh: [34, 31, 29, 33],
      vehicleDistribution: {
        cars: 691200,
        bikes: 504100,
        buses: 89300,
        trucks: 97800,
        autoRickshaws: 222610,
      },
      dayComparison: [
        {
          label: 'East Tech Belt Monthly',
          todayVehicles: 415800,
          previousPeriodVehicles: 391200,
          congestionDeltaPct: 6.3,
          avgSpeedDeltaKmh: -2.7,
        },
        {
          label: 'Central CBD Monthly',
          todayVehicles: 389400,
          previousPeriodVehicles: 396500,
          congestionDeltaPct: -1.8,
          avgSpeedDeltaKmh: 1.5,
        },
        {
          label: 'South Arterial Monthly',
          todayVehicles: 402150,
          previousPeriodVehicles: 388900,
          congestionDeltaPct: 3.4,
          avgSpeedDeltaKmh: -1.2,
        },
      ],
    },
  };

  return {
    generatedAt: now.toISOString(),
    dataSource: 'simulated_sensor_grid',
    summary: {
      totalVehiclesDetected,
      networkDensityScore,
      networkDensityLevel: classifyDensity(networkDensityScore),
      activeSignalsCount: signals.length,
      congestedRoadsCount,
      networkAvgSpeedKmh,
      vehicleTotals,
    },
    corridors,
    signals,
    alerts,
    hourlySeries,
    reports,
    recentVisionAnalyses: store.visionAnalyses,
  };
}
